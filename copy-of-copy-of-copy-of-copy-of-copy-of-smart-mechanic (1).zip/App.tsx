
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import CodeInput from './components/CodeInput';
import DiagnosisResultCard from './components/DiagnosisResult';
import ChatAssistant from './components/ChatAssistant';
import HomeDashboard from './components/HomeDashboard';
import SensorGuide from './components/SensorGuide';
import MaintenanceLog from './components/MaintenanceLog';
import AuthScreen from './components/AuthScreen';
import { AppMode, DiagnosisResult, FaultCodeData, TruckBrand, Language, User } from './types';
import { analyzeFaultCode } from './services/geminiService';
import { Home, Search, FileText, Wrench, MessageSquare } from 'lucide-react';
import { translations } from './utils/translations';

export const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.HOME);
  const [selectedBrand, setSelectedBrand] = useState<TruckBrand>('Renault');
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [diagnosis, setDiagnosis] = useState<DiagnosisResult | null>(null);
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');
  
  // New States
  const [lang, setLang] = useState<Language>('ar');
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Load persisted data
    const savedLang = localStorage.getItem('sm_lang') as Language;
    if (savedLang) setLang(savedLang);

    const savedUser = localStorage.getItem('sm_user');
    if (savedUser) setUser(JSON.parse(savedUser));
  }, []);

  const handleLangChange = (newLang: Language) => {
    setLang(newLang);
    localStorage.setItem('sm_lang', newLang);
  };

  const handleLogin = (newUser: User) => {
    setUser(newUser);
    localStorage.setItem('sm_user', JSON.stringify(newUser));
    setMode(AppMode.HOME);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('sm_user');
    setMode(AppMode.AUTH);
  };

  const handleUpgradeToPro = () => {
    if (!user) return;
    const upgradedUser = { ...user, isPro: true };
    setUser(upgradedUser);
    localStorage.setItem('sm_user', JSON.stringify(upgradedUser));
    alert('Congratulations! You are now a PRO member.');
  };

  const handleBrandSelect = (brand: TruckBrand) => {
    setSelectedBrand(brand);
    setSelectedModel(''); // Reset model when brand changes
  };

  const handleFaultSearch = async (data: FaultCodeData) => {
    setIsLoading(true);
    setDiagnosis(null);
    try {
      const result = await analyzeFaultCode(data, selectedBrand, selectedModel, lang);
      setDiagnosis(result);
    } catch (error) {
      console.error(error);
      alert("Error analyzing code");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleImageDiagnosis = (result: DiagnosisResult) => {
    setDiagnosis(result);
  };

  const handleGlobalSearch = (term: string) => {
    const isNumber = /\d/.test(term);
    
    if (isNumber) {
      if (term.toUpperCase().includes('PID') || term.toUpperCase().includes('SID')) {
         setGlobalSearchTerm(term);
         setMode(AppMode.SENSORS);
         return;
      }
      setMode(AppMode.DECODER);
    } else {
      setGlobalSearchTerm(term);
      setMode(AppMode.SENSORS);
    }
  };

  const renderContent = () => {
    switch (mode) {
      case AppMode.AUTH:
        return <AuthScreen onLogin={handleLogin} lang={lang} />;
      case AppMode.HOME:
        return (
          <HomeDashboard 
            onNavigate={setMode} 
            onSearchRequest={handleGlobalSearch} 
            selectedBrand={selectedBrand}
            onSelectBrand={handleBrandSelect}
            selectedModel={selectedModel}
            onSelectModel={setSelectedModel}
            lang={lang}
            user={user}
            onUpgrade={handleUpgradeToPro}
          />
        );
      case AppMode.DECODER:
        return (
          <div className="pb-4">
            <CodeInput 
              onSearch={handleFaultSearch} 
              isLoading={isLoading} 
              setIsLoading={setIsLoading}
              selectedBrand={selectedBrand} 
              selectedModel={selectedModel}
              lang={lang}
              onImageAnalysis={handleImageDiagnosis}
            />
            <DiagnosisResultCard result={diagnosis} />
          </div>
        );
      case AppMode.SENSORS:
        return <SensorGuide initialSearch={globalSearchTerm} />;
      case AppMode.MAINTENANCE:
        return <MaintenanceLog user={user} lang={lang} />;
      case AppMode.CHAT:
        return <div className="h-full"><ChatAssistant selectedBrand={selectedBrand} selectedModel={selectedModel} lang={lang} /></div>;
      default:
        return (
          <HomeDashboard 
            onNavigate={setMode} 
            onSearchRequest={handleGlobalSearch}
            selectedBrand={selectedBrand}
            onSelectBrand={handleBrandSelect}
            selectedModel={selectedModel}
            onSelectModel={setSelectedModel}
            lang={lang}
            user={user}
            onUpgrade={handleUpgradeToPro}
          />
        );
    }
  };

  const t = translations[lang];

  return (
    <div className="min-h-screen flex flex-col bg-zinc-100 font-sans" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      {/* Sticky Top Section containing Header and Nav */}
      <div className="sticky top-0 z-30 flex flex-col">
        <Header 
          selectedBrand={selectedBrand} 
          selectedModel={selectedModel} 
          lang={lang} 
          onLangChange={handleLangChange}
          user={user}
          onLogout={handleLogout}
          onLoginClick={() => setMode(AppMode.AUTH)}
        />
        
        {/* Navigation Bar - Moved to Top */}
        {mode !== AppMode.AUTH && (
          <div className="bg-white border-b border-zinc-200 shadow-sm overflow-x-auto no-scrollbar">
            <div className="flex justify-around items-center px-2 max-w-xl mx-auto min-w-max md:min-w-0 md:w-full">
              <NavButton 
                active={mode === AppMode.HOME} 
                onClick={() => setMode(AppMode.HOME)} 
                icon={<Home size={20} />} 
                label={t.home} 
              />
              <NavButton 
                active={mode === AppMode.DECODER} 
                onClick={() => setMode(AppMode.DECODER)} 
                icon={<Search size={20} />} 
                label={t.diagnostics} 
              />
              <NavButton 
                active={mode === AppMode.SENSORS} 
                onClick={() => {
                  setGlobalSearchTerm('');
                  setMode(AppMode.SENSORS);
                }} 
                icon={<FileText size={20} />} 
                label={t.sensors} 
              />
              <NavButton 
                active={mode === AppMode.MAINTENANCE} 
                onClick={() => setMode(AppMode.MAINTENANCE)} 
                icon={<Wrench size={20} />} 
                label={t.maintenance} 
              />
              <NavButton 
                active={mode === AppMode.CHAT} 
                onClick={() => setMode(AppMode.CHAT)} 
                icon={<MessageSquare size={20} />} 
                label={t.assistant} 
              />
            </div>
          </div>
        )}
      </div>

      {/* Main Scrollable Area */}
      <main className="flex-1 container mx-auto px-4 py-6 max-w-xl relative z-10">
        {renderContent()}
      </main>
    </div>
  );
};

interface NavButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const NavButton: React.FC<NavButtonProps> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 py-3 px-3 md:px-6 transition-all relative
      ${active ? 'text-red-600' : 'text-zinc-400 hover:text-zinc-600'}`}
  >
    <div className={`p-1 rounded-lg transition-all ${active ? 'bg-red-50' : 'bg-transparent'}`}>
      {icon}
    </div>
    <span className={`text-[10px] font-bold truncate ${active ? 'text-red-700' : 'text-zinc-500'}`}>{label}</span>
    
    {/* Active Indicator Bar */}
    {active && (
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600 rounded-t-full"></div>
    )}
  </button>
);
