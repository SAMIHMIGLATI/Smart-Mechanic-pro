
import React, { useState } from 'react';
import { User, Language } from '../types';
import { translations } from '../utils/translations';
import { Truck, Lock, Mail, User as UserIcon, ArrowRight } from 'lucide-react';

interface AuthScreenProps {
  onLogin: (user: User) => void;
  lang: Language;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, lang }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const t = translations[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call/Local storage
    const user: User = {
      name: name || 'User',
      email: email,
      isRegistered: true
    };
    onLogin(user);
  };

  return (
    <div className="min-h-full flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md border border-zinc-100">
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 bg-zinc-900 rounded-2xl flex items-center justify-center transform rotate-3">
             <Truck className="w-10 h-10 text-red-600" />
          </div>
        </div>
        
        <h2 className="text-2xl font-black text-center text-zinc-900 mb-2">
          {isRegister ? t.register : t.login}
        </h2>
        <p className="text-center text-zinc-500 text-sm mb-8">{t.loginPrompt}</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-sm font-bold text-zinc-700 mb-1">{t.name}</label>
              <div className="relative">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-3 pl-10 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-red-500 outline-none"
                  placeholder={t.name}
                />
                <UserIcon className="w-5 h-5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-bold text-zinc-700 mb-1">{t.email}</label>
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 pl-10 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-red-500 outline-none"
                placeholder="name@example.com"
              />
              <Mail className="w-5 h-5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-zinc-700 mb-1">{t.password}</label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 pl-10 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-red-500 outline-none"
                placeholder="••••••••"
              />
              <Lock className="w-5 h-5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-red-600 text-white font-bold py-4 rounded-xl hover:bg-red-700 transition-all shadow-lg shadow-red-600/20 mt-4 flex items-center justify-center gap-2"
          >
            {isRegister ? t.register : t.login}
            <ArrowRight className="w-5 h-5" />
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-zinc-500 text-sm hover:text-red-600 font-medium"
          >
            {isRegister ? 'لديك حساب بالفعل؟ تسجيل دخول' : 'ليس لديك حساب؟ إنشاء حساب جديد'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
