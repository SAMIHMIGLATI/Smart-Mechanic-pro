
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, MessageSquare } from 'lucide-react';
import { sendChatMessage } from '../services/geminiService';
import { ChatMessage, TruckBrand, Language } from '../types';

interface ChatAssistantProps {
  selectedBrand: TruckBrand;
  selectedModel: string;
  lang: Language;
}

const ChatAssistant: React.FC<ChatAssistantProps> = ({ selectedBrand, selectedModel, lang }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `أهلاً بك يا صديقي! 🛠️\nأنا مساعدك الذكي المتخصص في شاحنات ${selectedBrand} ${selectedModel}.\nيمكنك سؤالي عن مواصفات الزيوت، طريقة ضبط الصمامات، أو معاني الرموز الغريبة لهذه الشاحنة.`,
      timestamp: Date.now()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Update welcome message if brand/model changes
  useEffect(() => {
    if (messages.length === 1 && messages[0].id === 'welcome') {
       setMessages([{
        id: 'welcome',
        role: 'model',
        text: `أهلاً بك يا صديقي! 🛠️\nأنا مساعدك الذكي المتخصص في شاحنات ${selectedBrand} ${selectedModel}.\nيمكنك سؤالي عن مواصفات الزيوت، طريقة ضبط الصمامات، أو معاني الرموز الغريبة لهذه الشاحنة.`,
        timestamp: Date.now()
      }]);
    }
  }, [selectedBrand, selectedModel]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
      }));

      const responseText = await sendChatMessage(history, userMsg.text, selectedBrand, selectedModel, lang);

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText || 'عذراً، حدث خطأ تقني. حاول مرة أخرى.',
        timestamp: Date.now()
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: 'فشل الاتصال بالخادم. تأكد من اتصال الإنترنت.',
        timestamp: Date.now()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-zinc-200 h-[650px] flex flex-col">
      <div className="bg-zinc-900 p-4 flex items-center gap-3 shadow-md z-10">
        <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg">
          <MessageSquare className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="font-bold text-white text-lg">مساعد {selectedBrand}</h2>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-xs text-zinc-300">متصل الآن (AI Active)</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-zinc-50 scroll-smooth">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-end gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm
              ${msg.role === 'user' ? 'bg-red-600 text-white' : 'bg-white border border-zinc-200 text-blue-600'}`}>
              {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
            </div>
            
            <div className={`max-w-[85%] p-4 shadow-sm whitespace-pre-wrap leading-relaxed text-sm
              ${msg.role === 'user' 
                ? 'bg-red-600 text-white rounded-2xl rounded-br-none' 
                : 'bg-white text-zinc-800 border border-zinc-100 rounded-2xl rounded-bl-none'}`}>
              {msg.text}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-center gap-2 p-4 bg-white rounded-2xl rounded-bl-none max-w-[100px] border border-zinc-100 shadow-sm mr-11">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" />
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-75" />
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-150" />
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-zinc-100">
        <form onSubmit={handleSend} className="flex gap-2 relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`اسأل عن أعطال ${selectedBrand} ${selectedModel}...`}
            className="flex-1 p-4 pl-12 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-red-500 transition-all placeholder-zinc-400"
            disabled={isLoading}
          />
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="p-4 bg-red-600 text-white rounded-xl hover:bg-red-700 disabled:bg-zinc-200 disabled:text-zinc-400 transition-all shadow-md active:scale-95"
          >
            <Send className="w-5 h-5 ltr:rotate-180" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatAssistant;