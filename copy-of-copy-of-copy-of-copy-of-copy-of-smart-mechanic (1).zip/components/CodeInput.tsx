
import React, { useState, useRef, useEffect } from 'react';
import { FaultCodeData, TruckBrand, Language, DiagnosisResult } from '../types';
import { Search, Hash, Server, Activity, Truck, Camera, Upload, X, ScanLine, Keyboard, Image as ImageIcon, RefreshCcw, Aperture } from 'lucide-react';
import { translations } from '../utils/translations';
import { analyzeImageFault } from '../services/geminiService';

interface CodeInputProps {
  onSearch: (data: FaultCodeData) => void;
  isLoading: boolean;
  selectedBrand: TruckBrand;
  selectedModel: string;
  lang: Language;
  onImageAnalysis?: (result: DiagnosisResult) => void;
  setIsLoading?: (loading: boolean) => void;
}

const CodeInput: React.FC<CodeInputProps> = ({ onSearch, isLoading, selectedBrand, selectedModel, lang, onImageAnalysis, setIsLoading }) => {
  const [activeTab, setActiveTab] = useState<'manual' | 'camera'>('manual');
  
  // Manual State
  const [mid, setMid] = useState('');
  const [pidSid, setPidSid] = useState('');
  const [isSid, setIsSid] = useState(false);
  const [fmi, setFmi] = useState('');
  
  // Camera State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const t = translations[lang];

  // Cleanup camera stream on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsStreaming(false);
  };

  const startCamera = async () => {
    try {
      // Request camera with preference for environment (rear) camera
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsStreaming(true);
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      alert(t.cameraError || 'Unable to access camera');
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      // Draw frame
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageDataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setSelectedImage(imageDataUrl);
        stopCamera();
      }
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mid || !pidSid || !fmi) return;

    const data: FaultCodeData = {
      mid,
      fmi,
      pid: !isSid ? pidSid : undefined,
      sid: isSid ? pidSid : undefined,
    };
    onSearch(data);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageAnalyze = async () => {
    if (!selectedImage || !setIsLoading || !onImageAnalysis) return;
    
    setIsLoading(true);
    try {
      // Extract base64 content only (remove data:image/jpeg;base64, prefix)
      const base64Data = selectedImage.split(',')[1];
      const result = await analyzeImageFault(base64Data, selectedBrand, selectedModel, lang);
      onImageAnalysis(result);
    } catch (error) {
      console.error(error);
      alert('Error analyzing image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleRetake = () => {
    setSelectedImage(null);
    startCamera();
  };

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-zinc-200">
      <div className="bg-zinc-900 border-b border-zinc-800">
        <div className="flex px-2 pt-2 gap-1">
          <button
            onClick={() => {
              setActiveTab('manual');
              stopCamera();
            }}
            className={`flex-1 py-3 text-sm font-bold uppercase tracking-wider rounded-t-lg transition-all flex items-center justify-center gap-2
              ${activeTab === 'manual' 
                ? 'bg-zinc-50 text-red-600' 
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'}`}
          >
            <Keyboard className="w-4 h-4" />
            {t.manualInput}
          </button>
          <button
            onClick={() => setActiveTab('camera')}
            className={`flex-1 py-3 text-sm font-bold uppercase tracking-wider rounded-t-lg transition-all flex items-center justify-center gap-2
              ${activeTab === 'camera' 
                ? 'bg-zinc-50 text-red-600' 
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'}`}
          >
            <Camera className="w-4 h-4" />
            {t.cameraScan}
          </button>
        </div>
      </div>

      <div className="p-6 md:p-8 bg-zinc-50 relative">
        {/* Truck Info Badge */}
        <div className="absolute top-4 right-4 md:top-6 md:right-8 flex items-center gap-2 text-[10px] font-mono text-zinc-400 bg-white px-2 py-1 rounded-full border border-zinc-200 shadow-sm z-10">
          <Truck className="w-3 h-3" />
          {selectedBrand} {selectedModel}
        </div>

        {activeTab === 'manual' ? (
          <form onSubmit={handleManualSubmit} className="space-y-8 animate-in fade-in slide-in-from-left-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
              {/* MID Input */}
              <div className="group">
                <label className="flex items-center gap-2 text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">
                  <Server className="w-4 h-4" />
                  {t.midLabel}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={mid}
                    onChange={(e) => setMid(e.target.value)}
                    placeholder="128"
                    className="w-full h-14 pl-4 pr-4 bg-white border-2 border-zinc-200 rounded-lg text-2xl font-mono font-bold text-zinc-800 focus:border-red-600 focus:ring-0 transition-colors placeholder-zinc-200 shadow-sm"
                    required
                  />
                </div>
              </div>

              {/* PID/SID Input */}
              <div className="group">
                <div className="flex justify-between items-center mb-2">
                  <label className="flex items-center gap-2 text-xs font-bold text-zinc-500 uppercase tracking-wider">
                    <Hash className="w-4 h-4" />
                    {t.pidSidLabel}
                  </label>
                  <button 
                    type="button" 
                    onClick={() => setIsSid(!isSid)}
                    className="text-[10px] px-2 py-0.5 bg-zinc-200 hover:bg-zinc-300 text-zinc-700 rounded font-bold transition-colors"
                  >
                    {isSid ? 'Switch to PID' : 'Switch to SID'}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    value={pidSid}
                    onChange={(e) => setPidSid(e.target.value)}
                    placeholder="131"
                    className="w-full h-14 pl-4 pr-4 bg-white border-2 border-zinc-200 rounded-lg text-2xl font-mono font-bold text-zinc-800 focus:border-red-600 focus:ring-0 transition-colors placeholder-zinc-200 shadow-sm"
                    required
                  />
                </div>
              </div>

              {/* FMI Input */}
              <div className="group">
                <label className="flex items-center gap-2 text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">
                  <Activity className="w-4 h-4" />
                  {t.fmiLabel}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={fmi}
                    onChange={(e) => setFmi(e.target.value)}
                    placeholder="05"
                    className="w-full h-14 pl-4 pr-4 bg-white border-2 border-zinc-200 rounded-lg text-2xl font-mono font-bold text-zinc-800 focus:border-red-600 focus:ring-0 transition-colors placeholder-zinc-200 shadow-sm"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-4 items-center pt-2">
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full md:w-auto md:min-w-[200px] h-14 rounded-lg text-white font-bold text-lg shadow-lg shadow-red-600/20 transition-all transform active:scale-[0.98] flex items-center justify-center gap-3
                  ${isLoading 
                    ? 'bg-zinc-700 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600'
                  }`}
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>{t.processing}</span>
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5" />
                    <span>{t.analyze}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-6 pt-4 animate-in fade-in slide-in-from-right-4 duration-300">
            <input 
              type="file" 
              accept="image/*"
              ref={fileInputRef}
              onChange={handleImageSelect}
              className="hidden" 
            />
            
            {/* Hidden Canvas for Capture */}
            <canvas ref={canvasRef} className="hidden" />

            {!selectedImage && !isStreaming && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Start Camera Button */}
                <div 
                  onClick={startCamera}
                  className="border-2 border-dashed border-zinc-300 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-red-400 hover:bg-red-50/50 transition-all group min-h-[200px]"
                >
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-sm">
                    <Camera className="w-8 h-8 text-red-600" />
                  </div>
                  <h3 className="font-bold text-zinc-700 text-lg">{t.startCamera}</h3>
                </div>

                {/* Upload File Button */}
                <div 
                  onClick={triggerFileInput}
                  className="border-2 border-dashed border-zinc-300 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50/50 transition-all group min-h-[200px]"
                >
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-sm">
                    <ImageIcon className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-zinc-700 text-lg">{t.uploadFile}</h3>
                </div>
              </div>
            )}

            {/* Live Camera View */}
            {isStreaming && (
              <div className="relative rounded-2xl overflow-hidden border-2 border-zinc-900 shadow-2xl bg-black aspect-[3/4] md:aspect-video mx-auto max-w-md">
                <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline
                  className="w-full h-full object-cover"
                />
                
                {/* Camera Overlay Controls */}
                <div className="absolute bottom-6 left-0 right-0 flex justify-center items-center gap-8 z-20">
                   <button 
                     onClick={stopCamera}
                     className="p-4 bg-zinc-900/50 rounded-full text-white backdrop-blur-sm hover:bg-zinc-800 transition-colors"
                   >
                     <X className="w-6 h-6" />
                   </button>
                   
                   <button 
                     onClick={captureImage}
                     className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center bg-red-600/80 hover:bg-red-600 transition-all active:scale-95 shadow-lg"
                   >
                     <Aperture className="w-8 h-8 text-white" />
                   </button>
                   
                   <div className="w-14"></div> {/* Spacer for balance */}
                </div>
              </div>
            )}
            
            {/* Image Preview */}
            {selectedImage && (
              <div className="space-y-6">
                 <div className="relative rounded-2xl overflow-hidden border border-zinc-200 shadow-lg bg-black max-w-md mx-auto">
                   <img src={selectedImage} alt="Preview" className="w-full max-h-[400px] object-contain" />
                   <button 
                     onClick={() => setSelectedImage(null)}
                     className="absolute top-2 right-2 p-2 bg-black/60 text-white rounded-full hover:bg-red-600 transition-colors backdrop-blur-sm"
                   >
                     <X className="w-5 h-5" />
                   </button>
                 </div>
                 
                 <div className="flex flex-col md:flex-row gap-3">
                   <button
                      onClick={handleRetake}
                      className="flex-1 h-14 rounded-lg bg-zinc-100 text-zinc-700 font-bold text-lg hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2"
                   >
                      <RefreshCcw className="w-5 h-5" />
                      {t.cameraScan}
                   </button>

                   <button
                      onClick={handleImageAnalyze}
                      disabled={isLoading}
                      className={`flex-[2] h-14 rounded-lg text-white font-bold text-lg shadow-lg shadow-red-600/20 transition-all transform active:scale-[0.98] flex items-center justify-center gap-3
                        ${isLoading 
                          ? 'bg-zinc-700 cursor-not-allowed' 
                          : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600'
                        }`}
                    >
                      {isLoading ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          <span>{t.analyzingImage}</span>
                        </>
                      ) : (
                        <>
                          <ScanLine className="w-5 h-5" />
                          <span>{t.analyze}</span>
                        </>
                      )}
                    </button>
                 </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeInput;
