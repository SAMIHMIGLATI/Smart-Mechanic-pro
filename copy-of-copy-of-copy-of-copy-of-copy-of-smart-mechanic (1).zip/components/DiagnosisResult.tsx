import React from 'react';
import { DiagnosisResult } from '../types';
import { AlertTriangle, Wrench, Activity, CheckCircle2, AlertOctagon, Cpu, FileText, ListChecks } from 'lucide-react';

interface DiagnosisResultProps {
  result: DiagnosisResult | null;
}

const DiagnosisResultCard: React.FC<DiagnosisResultProps> = ({ result }) => {
  if (!result) return null;

  const severityConfig = {
    low: {
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
      border: 'border-emerald-200',
      icon: <CheckCircle2 className="w-8 h-8 text-emerald-500" />,
      label: 'خطورة منخفضة'
    },
    medium: {
      color: 'text-amber-600',
      bg: 'bg-amber-50',
      border: 'border-amber-200',
      icon: <AlertTriangle className="w-8 h-8 text-amber-500" />,
      label: 'خطورة متوسطة'
    },
    high: {
      color: 'text-red-600',
      bg: 'bg-red-50',
      border: 'border-red-200',
      icon: <AlertOctagon className="w-8 h-8 text-red-500" />,
      label: 'خطورة عالية'
    }
  };

  const config = severityConfig[result.severity];

  return (
    <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700">
      
      {/* Main Status Card */}
      <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-zinc-100">
        <div className={`p-1 h-2 w-full ${result.severity === 'high' ? 'bg-red-500' : result.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 text-zinc-500 text-sm font-bold uppercase tracking-wider mb-2">
                <Cpu className="w-4 h-4" />
                النظام المتأثر
              </div>
              <h2 className="text-3xl font-black text-zinc-800 mb-4">{result.system}</h2>
              <div className="prose prose-lg text-zinc-600 leading-relaxed">
                <p>{result.description}</p>
              </div>
            </div>
            
            <div className={`flex flex-col items-center justify-center p-6 rounded-xl ${config.bg} border ${config.border} min-w-[160px]`}>
              {config.icon}
              <span className={`mt-2 font-bold ${config.color}`}>{config.label}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Causes & Symptoms */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-lg border border-zinc-100 h-full">
            <div className="flex items-center gap-2 mb-6 pb-4 border-b border-zinc-100">
              <Activity className="w-5 h-5 text-red-500" />
              <h3 className="font-bold text-lg text-zinc-800">الأسباب المحتملة (Causes)</h3>
            </div>
            <ul className="space-y-4">
              {result.causes.map((cause, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <span className="text-zinc-700 font-medium">{cause}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-zinc-100 h-full">
            <div className="flex items-center gap-2 mb-6 pb-4 border-b border-zinc-100">
              <FileText className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-lg text-zinc-800">الأعراض الظاهرة (Symptoms)</h3>
            </div>
            <ul className="space-y-3">
              {result.symptoms.map((symptom, idx) => (
                <li key={idx} className="flex items-start gap-3 bg-amber-50/50 p-3 rounded-lg border border-amber-100/50">
                  <span className="w-2 h-2 bg-amber-400 rounded-full mt-2 shrink-0"></span>
                  <span className="text-zinc-700">{symptom}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Solutions Timeline */}
        <div className="bg-zinc-900 text-white p-6 rounded-xl shadow-xl flex flex-col">
          <div className="flex items-center gap-2 mb-8 border-b border-zinc-800 pb-4">
            <ListChecks className="w-6 h-6 text-green-400" />
            <h3 className="font-bold text-xl">خطوات الإصلاح (Repair Steps)</h3>
          </div>
          
          <div className="space-y-0 relative pl-4 flex-1">
            {/* Vertical Line */}
            <div className="absolute right-0 top-2 bottom-4 w-0.5 bg-zinc-700 md:right-4"></div>

            {result.solutions.map((solution, idx) => (
              <div key={idx} className="relative flex items-start gap-6 mb-8 last:mb-0 group">
                <div className="flex-1 bg-zinc-800/50 p-4 rounded-lg border border-zinc-700/50 hover:bg-zinc-800 transition-colors">
                  <p className="text-zinc-300 leading-relaxed">{solution}</p>
                </div>
                {/* Timeline Dot */}
                <div className="absolute -right-1.5 md:right-[11px] top-4 w-4 h-4 rounded-full bg-zinc-900 border-4 border-green-500 z-10"></div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 pt-4 border-t border-zinc-800">
            <div className="flex items-start gap-3 text-xs text-zinc-400 bg-zinc-950 p-3 rounded">
              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
              <p>تنبيه: يجب تنفيذ الخطوات بواسطة فني مختص. استخدم معدات السلامة المناسبة.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiagnosisResultCard;