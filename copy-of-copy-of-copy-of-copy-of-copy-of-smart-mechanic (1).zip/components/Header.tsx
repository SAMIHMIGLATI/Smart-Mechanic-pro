
import React, { useState, useEffect } from 'react';
import { Truck, Globe, User, LogOut, Info, X, CheckCircle2, Code2, Phone, Crown } from 'lucide-react';
import { TruckBrand, Language, User as UserType } from '../types';
import { translations } from '../utils/translations';

interface HeaderProps {
  selectedBrand?: TruckBrand;
  selectedModel?: string;
  lang: Language;
  onLangChange: (lang: Language) => void;
  user: UserType | null;
  onLogout: () => void;
  onLoginClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ selectedBrand, selectedModel, lang, onLangChange, user, onLogout, onLoginClick }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const t = translations[lang];

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <>
      <header className="bg-zinc-900 text-white shadow-xl border-b border-zinc-800 relative z-20 pt-safe-area">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              
              {/* Simple Elegant Logo */}
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-xl flex items-center justify-center shadow-lg shadow-red-600/20 border border-red-500/30 group cursor-pointer hover:scale-105 transition-transform">
                 <Truck className="w-7 h-7 text-white drop-shadow-md" />
              </div>

              <div>
                <div className="flex items-center gap-1">
                   <h1 className="text-xl md:text-2xl font-black tracking-tighter uppercase font-sans leading-none italic">
                    SMART<span className="text-red-600 text-3xl">.</span>
                  </h1>
                </div>
                
                <div className="flex items-center gap-1.5 mt-0.5">
                   <div className="h-0.5 w-4 bg-red-600 rounded-full"></div>
                   <p className="text-[10px] text-zinc-400 font-bold tracking-[0.2em] uppercase">
                     Mechanic
                   </p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 md:gap-3">
              {/* About Button */}
              <button 
                onClick={() => setShowAboutModal(true)}
                className="p-2 hover:bg-zinc-800 rounded-full transition-colors border border-transparent hover:border-zinc-700"
              >
                <Info className="w-5 h-5 text-zinc-400" />
              </button>

              {/* Language Selector */}
              <div className="relative">
                <button 
                  onClick={() => setShowLangMenu(!showLangMenu)}
                  className="p-2 hover:bg-zinc-800 rounded-full transition-colors flex items-center gap-1 border border-zinc-800"
                >
                  <Globe className="w-4 h-4 text-zinc-400" />
                  <span className="text-xs font-bold text-zinc-400 uppercase">{lang}</span>
                </button>
                
                {showLangMenu && (
                  <div className="absolute top-full right-0 mt-2 w-32 bg-zinc-800 rounded-lg shadow-xl border border-zinc-700 overflow-hidden z-30">
                    <button onClick={() => { onLangChange('ar'); setShowLangMenu(false); }} className="w-full text-right px-4 py-2 text-zinc-200 hover:bg-zinc-700 text-sm font-bold">العربية</button>
                    <button onClick={() => { onLangChange('en'); setShowLangMenu(false); }} className="w-full text-right px-4 py-2 text-zinc-200 hover:bg-zinc-700 text-sm font-bold">English</button>
                    <button onClick={() => { onLangChange('fr'); setShowLangMenu(false); }} className="w-full text-right px-4 py-2 text-zinc-200 hover:bg-zinc-700 text-sm font-bold">Français</button>
                  </div>
                )}
              </div>

              {/* User Menu */}
              <div className="relative">
                <button 
                  onClick={() => user ? setShowUserMenu(!showUserMenu) : onLoginClick()}
                  className="group relative p-0.5 rounded-full transition-all"
                >
                  <div className={`absolute -inset-0.5 rounded-full opacity-70 group-hover:opacity-100 blur-[2px] transition-opacity ${user?.isPro ? 'bg-gradient-to-r from-amber-400 to-yellow-600' : 'bg-gradient-to-r from-red-600 to-zinc-600'}`}></div>
                  <div className={`relative w-9 h-9 rounded-full flex items-center justify-center border-2 ${user ? 'bg-zinc-900 border-transparent text-white' : 'bg-zinc-900 border-zinc-900 text-zinc-400'}`}>
                    {user ? <span className="font-black text-xs">{user.name.charAt(0).toUpperCase()}</span> : <User className="w-4 h-4" />}
                  </div>
                  
                  {user?.isPro && (
                    <div className="absolute -top-1 -right-1 bg-gradient-to-br from-amber-300 to-yellow-600 text-[8px] font-black text-black px-1 rounded-full shadow-lg border border-white/20 z-10">
                      PRO
                    </div>
                  )}
                </button>

                {showUserMenu && user && (
                  <div className="absolute top-full right-0 mt-2 w-56 bg-zinc-900 rounded-xl shadow-2xl border border-zinc-800 overflow-hidden z-30">
                    <div className="px-4 py-4 border-b border-zinc-800 bg-zinc-900/50">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-bold text-white">{user.name}</p>
                        {user.isPro && <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />}
                      </div>
                      <p className="text-[10px] text-zinc-500 truncate font-mono">{user.email}</p>
                    </div>
                    <button 
                      onClick={() => { onLogout(); setShowUserMenu(false); }}
                      className="w-full text-right px-4 py-3 text-red-500 hover:bg-red-950/20 text-sm flex items-center gap-2 font-bold transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      {t.logout}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* About Modal */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl relative animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-zinc-900 p-6 pb-12 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4">
                 <button onClick={() => setShowAboutModal(false)} className="bg-zinc-800/50 hover:bg-zinc-700 text-white rounded-full p-2 transition-colors">
                    <X className="w-5 h-5" />
                 </button>
              </div>
              <div className="flex flex-col items-center relative z-10">
                <div className="w-16 h-16 bg-gradient-to-br from-red-600 to-red-800 rounded-2xl flex items-center justify-center shadow-lg shadow-red-900/40 mb-3 border border-white/10">
                   <Truck className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-black text-white tracking-tighter">SMART<span className="text-red-500">.</span> MECHANIC</h2>
                <p className="text-zinc-300 text-[11px] font-medium mt-1 font-sans">Developed by programmer Samih Meguelati</p>
                <p className="text-zinc-500 text-[10px] font-bold tracking-widest uppercase mt-2">{t.version}</p>
              </div>
              
              {/* Decorative Circles */}
              <div className="absolute -left-4 -bottom-4 w-24 h-24 bg-red-600/20 rounded-full blur-2xl"></div>
              <div className="absolute right-10 top-10 w-32 h-32 bg-blue-600/10 rounded-full blur-3xl"></div>
            </div>

            {/* Modal Content */}
            <div className="px-6 py-6 -mt-6 bg-white rounded-t-3xl relative">
              <div className="space-y-6">
                
                {/* App Description */}
                <div>
                   <h3 className="font-bold text-zinc-800 mb-2 flex items-center gap-2">
                     <Info className="w-4 h-4 text-red-500" />
                     {t.aboutTitle}
                   </h3>
                   <p className="text-zinc-600 text-sm leading-relaxed bg-zinc-50 p-3 rounded-xl border border-zinc-100">
                     {t.aboutAppDesc}
                   </p>
                </div>

                {/* Features */}
                <div>
                   <h3 className="font-bold text-zinc-800 mb-2 text-sm">{t.features}</h3>
                   <ul className="space-y-2">
                      <li className="flex items-center gap-2 text-xs font-medium text-zinc-600">
                        <CheckCircle2 className="w-4 h-4 text-green-500" /> {t.feature1}
                      </li>
                      <li className="flex items-center gap-2 text-xs font-medium text-zinc-600">
                        <CheckCircle2 className="w-4 h-4 text-green-500" /> {t.feature2}
                      </li>
                      <li className="flex items-center gap-2 text-xs font-medium text-zinc-600">
                        <CheckCircle2 className="w-4 h-4 text-green-500" /> {t.feature3}
                      </li>
                   </ul>
                </div>

                {/* Developer Info */}
                <div className="pt-4 border-t border-zinc-100">
                   <h3 className="font-bold text-zinc-800 mb-3 flex items-center gap-2">
                     <Code2 className="w-4 h-4 text-blue-500" />
                     {t.developerTitle}
                   </h3>
                   
                   <div className="flex items-start gap-4 bg-zinc-900 rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
                      <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-zinc-800 to-transparent opacity-50"></div>
                      
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shrink-0 shadow-md text-zinc-900 font-black text-sm border-2 border-zinc-200 z-10">
                        SM
                      </div>
                      
                      <div className="relative z-10">
                         <h4 className="font-light text-lg tracking-wide">Samih Meguelati</h4>
                         <p className="text-[10px] text-zinc-400 leading-relaxed mt-1">
                           {t.developerBio}
                         </p>
                      </div>
                   </div>
                </div>

                {/* Contact & Support Section */}
                <div className="pt-4 border-t border-zinc-100">
                   <h3 className="font-bold text-zinc-800 mb-3 flex items-center gap-2">
                     <Phone className="w-4 h-4 text-green-600" />
                     {t.contactSupport}
                   </h3>
                   <div className="grid grid-cols-1 gap-3">
                      <a href="tel:0550317113" className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border border-green-100 hover:bg-green-100 transition-colors group">
                         <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg shadow-green-500/30 group-hover:scale-110 transition-transform">
                            <Phone className="w-5 h-5" />
                         </div>
                         <div>
                            <p className="text-[10px] text-green-600 font-bold uppercase tracking-wider">Mobile 1</p>
                            <p className="text-lg font-black text-zinc-800 font-mono tracking-wider">0550 31 71 13</p>
                         </div>
                      </a>
                      <a href="tel:0556080466" className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border border-green-100 hover:bg-green-100 transition-colors group">
                         <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg shadow-green-500/30 group-hover:scale-110 transition-transform">
                            <Phone className="w-5 h-5" />
                         </div>
                         <div>
                            <p className="text-[10px] text-green-600 font-bold uppercase tracking-wider">Mobile 2</p>
                            <p className="text-lg font-black text-zinc-800 font-mono tracking-wider">0556 08 04 66</p>
                         </div>
                      </a>
                   </div>
                </div>

                <button 
                  onClick={() => setShowAboutModal(false)}
                  className="w-full py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-xl font-bold transition-colors text-sm"
                >
                  {t.close}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;
