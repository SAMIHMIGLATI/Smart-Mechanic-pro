
import React, { useState, useEffect } from 'react';
import { AppMode, TruckBrand, Language, User } from '../types';
import { Search, Code2, Github, Globe, ArrowRight, Download, Activity, Truck, Zap, Crown, Check, X } from 'lucide-react';
import { translations } from '../utils/translations';

interface HomeDashboardProps {
  onNavigate: (mode: AppMode) => void;
  onSearchRequest: (term: string) => void;
  selectedBrand: TruckBrand;
  onSelectBrand: (brand: TruckBrand) => void;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  lang: Language;
  user: User | null;
  onUpgrade?: () => void;
}

const brandLogos: Record<TruckBrand, string> = {
  Renault: 'https://cdn.simpleicons.org/renault/FFCC33',
  Volvo: 'https://cdn.simpleicons.org/volvo/14296C',
  Scania: 'https://cdn.simpleicons.org/scania/041E42',
  MAN: 'https://cdn.simpleicons.org/man/E40045',
  DAF: 'https://cdn.simpleicons.org/daf/005C94',
  Iveco: 'https://cdn.simpleicons.org/iveco/004899'
};

const brandColors: Record<TruckBrand, string> = {
  Renault: 'border-yellow-400 shadow-yellow-500/20 bg-yellow-50',
  Volvo: 'border-blue-800 shadow-blue-800/20 bg-blue-50',
  Scania: 'border-blue-900 shadow-blue-900/20 bg-blue-50',
  MAN: 'border-red-600 shadow-red-600/20 bg-red-50',
  DAF: 'border-sky-600 shadow-sky-600/20 bg-sky-50',
  Iveco: 'border-indigo-600 shadow-indigo-600/20 bg-indigo-50'
};

interface TruckModel {
  name: string;
}

const brandModels: Record<TruckBrand, TruckModel[]> = {
  Renault: [
    { name: 'Kerax' },
    { name: 'Premium' },
    { name: 'Magnum' },
    { name: 'Midlum' },
    { name: 'K-Series' },
    { name: 'T-Series' }
  ],
  Volvo: [
    { name: 'FH' },
    { name: 'FM' },
    { name: 'FMX' },
    { name: 'FL' }
  ],
  Scania: [
    { name: 'R-Series' },
    { name: 'P-Series' },
    { name: 'G-Series' },
    { name: 'S-Series' }
  ],
  MAN: [
    { name: 'TGX' },
    { name: 'TGS' },
    { name: 'TGM' }
  ],
  DAF: [
    { name: 'XF' },
    { name: 'CF' },
    { name: 'LF' }
  ],
  Iveco: [
    { name: 'Stralis' },
    { name: 'Trakker' },
    { name: 'S-Way' }
  ]
};

const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onNavigate,
  onSearchRequest,
  selectedBrand,
  onSelectBrand,
  selectedModel,
  onSelectModel,
  lang,
  user,
  onUpgrade
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [showProModal, setShowProModal] = useState(false);
  const t = translations[lang];

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    installPrompt.userChoice.then((choiceResult: any) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted the install prompt');
      }
      setInstallPrompt(null);
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearchRequest(searchTerm);
    }
  };

  const handleUpgradeClick = () => {
    if (onUpgrade) {
      onUpgrade();
      setShowProModal(false);
    }
  };

  // Reliable Scania Image URL
  const scaniaImage = 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?q=80&w=1920&auto=format&fit=crop';
  const fallbackImage = 'https://images.unsplash.com/photo-1591768793355-74d04bb6608f?q=80&w=1920&auto=format&fit=crop';

  return (
    <div className="space-y-8 pb-24 animate-in fade-in duration-700">
      {/* Welcome Section with Fixed Scania Image */}
      <div className="relative bg-zinc-900 rounded-3xl p-6 md:p-8 text-white shadow-2xl shadow-zinc-900/30 overflow-hidden border border-zinc-800 group min-h-[280px] flex flex-col justify-center">

        {/* Dynamic Background Image */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img
            src={scaniaImage}
            onError={(e) => { e.currentTarget.src = fallbackImage; }}
            alt="Scania Truck"
            className="w-full h-full object-cover opacity-60 transition-transform duration-[10s] ease-out scale-100"
            style={{ 
              animation: 'kenburns 20s ease-out infinite alternate',
            }}
          />
          {/* Gradient Overlay to ensure text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-900/70 to-transparent"></div>
          
          <style>{`
            @keyframes kenburns {
              0% { transform: scale(1); }
              100% { transform: scale(1.15); }
            }
          `}</style>
        </div>

        <div className="relative z-10 max-w-lg">
           <div className="inline-flex items-center gap-2 bg-red-600/20 border border-red-500/30 rounded-full px-3 py-1 mb-4 backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              <span className="text-[10px] font-bold text-red-200 uppercase tracking-widest">AI Connected</span>
           </div>

           <h1 className="text-4xl md:text-5xl font-black mb-3 flex flex-wrap items-center gap-2 tracking-tight">
             {t.welcome} <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-amber-500">{user ? user.name : ''}</span>
           </h1>
           <p className="text-zinc-300 font-medium mb-8 max-w-[90%] leading-relaxed text-sm md:text-base drop-shadow-md">
             {t.smartMechanic} - نظام الذكاء الاصطناعي الأقوى لتشخيص الأعطال {selectedBrand ? `لشاحنات ${selectedBrand}` : ''}.
           </p>

           <form onSubmit={handleSearchSubmit} className="relative group/input max-w-md">
             <div className="absolute -inset-0.5 bg-gradient-to-r from-red-600 to-orange-600 rounded-2xl opacity-30 group-hover/input:opacity-70 blur transition duration-500"></div>
             <div className="relative flex items-center bg-zinc-950/80 backdrop-blur-md rounded-xl overflow-hidden border border-zinc-700/50 group-hover/input:border-zinc-500 transition-colors">
               <Search className="w-5 h-5 text-zinc-400 ml-4" />
               <input
                 type="text"
                 value={searchTerm}
                 onChange={(e) => setSearchTerm(e.target.value)}
                 placeholder={t.quickSearch}
                 className="w-full h-12 px-4 bg-transparent text-white placeholder-zinc-400 focus:outline-none font-medium"
               />
               {searchTerm && (
                  <button
                    type="button"
                    onClick={() => onSearchRequest(searchTerm)}
                    className="mr-2 bg-red-600 hover:bg-red-500 text-white p-2 rounded-lg transition-colors"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
               )}
             </div>
           </form>
        </div>
      </div>

      {/* Pro Version Promo Banner (Show only if not Pro) */}
      {!user?.isPro && (
        <div 
          onClick={() => setShowProModal(true)}
          className="relative bg-gradient-to-r from-amber-400 to-yellow-500 rounded-2xl p-5 shadow-lg shadow-amber-500/20 cursor-pointer hover:scale-[1.02] transition-transform overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
            <Crown className="w-24 h-24 text-black" />
          </div>
          
          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-black/10 rounded-xl flex items-center justify-center text-zinc-900 backdrop-blur-sm">
                 <Crown className="w-6 h-6 fill-zinc-900" />
              </div>
              <div>
                <h3 className="font-black text-zinc-900 text-lg uppercase tracking-tight">{t.upgradeToPro}</h3>
                <p className="text-zinc-800 text-xs font-bold opacity-80">{t.proDesc}</p>
              </div>
            </div>
            <div className="bg-zinc-900 text-amber-400 px-4 py-2 rounded-lg font-bold text-xs shadow-md">
              {t.proBadge}
            </div>
          </div>
        </div>
      )}

      {/* Install App Banner (Only if available) */}
      {installPrompt && (
        <div className="bg-gradient-to-r from-white to-zinc-50 p-4 rounded-2xl border border-zinc-200 flex items-center justify-between shadow-lg animate-in slide-in-from-top-4 relative overflow-hidden">
          <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-red-50 to-transparent"></div>
          <div className="flex items-center gap-4 relative z-10">
             <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center shadow-lg shadow-zinc-900/10 text-white">
                <Download className="w-6 h-6 animate-bounce" />
             </div>
             <div>
               <h3 className="font-bold text-zinc-900">{t.installApp}</h3>
               <p className="text-xs text-zinc-500 font-medium">{t.installDesc}</p>
             </div>
          </div>
          <button 
            onClick={handleInstallClick}
            className="relative z-10 bg-red-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-red-600/30 active:scale-95 transition-all hover:bg-red-700"
          >
            {t.install}
          </button>
        </div>
      )}

      {/* Brand Selection - Elegant Grid */}
      <div className="space-y-5">
        <h2 className="text-lg font-black text-zinc-800 flex items-center gap-3 px-1 uppercase tracking-wider">
          <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
          {t.selectBrand}
        </h2>
        
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
          {(Object.keys(brandLogos) as TruckBrand[]).map((brand) => (
            <button
              key={brand}
              onClick={() => onSelectBrand(brand)}
              className={`relative group h-32 rounded-2xl p-3 flex flex-col items-center justify-center transition-all duration-500 border
                ${selectedBrand === brand 
                  ? `${brandColors[brand]} scale-105 shadow-2xl z-10` 
                  : 'bg-white border-zinc-100 shadow-sm hover:shadow-lg hover:border-zinc-200 hover:bg-zinc-50'}`}
            >
              {/* Brand Glow Effect */}
              {selectedBrand === brand && (
                <span className="absolute inset-0 rounded-2xl opacity-20 bg-current blur-xl -z-10 animate-pulse"></span>
              )}

              <div className={`relative transition-all duration-700 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${selectedBrand === brand ? 'rotate-[360deg] -translate-y-2 scale-110' : ''}`}>
                <img 
                  src={brandLogos[brand]} 
                  alt={brand} 
                  className={`w-12 h-12 object-contain drop-shadow-sm transition-opacity duration-300
                    ${selectedBrand === brand ? 'opacity-100' : 'opacity-80 group-hover:opacity-100 group-hover:scale-110'}`} 
                />
              </div>
              
              <span className={`text-[11px] font-black tracking-wide uppercase absolute bottom-3 transition-all duration-500
                ${selectedBrand === brand 
                  ? 'translate-y-0 opacity-100 scale-110 text-zinc-900' // Pop out effect
                  : 'translate-y-1 opacity-0 group-hover:opacity-60 group-hover:translate-y-0 text-zinc-400'}`}>
                {brand}
              </span>

              {selectedBrand === brand && (
                <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-green-500 shadow-sm animate-ping" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Model Selection - Visual Cards (No Images) */}
      {selectedBrand && (
        <div className="space-y-5 animate-in slide-in-from-bottom-8 duration-500">
          <h2 className="text-lg font-black text-zinc-800 flex items-center gap-3 px-1 uppercase tracking-wider">
             <span className="w-1.5 h-6 bg-zinc-800 rounded-full"></span>
             {t.selectModel} <span className="text-zinc-400 font-bold text-xs bg-zinc-100 px-2 py-0.5 rounded-full">{selectedBrand}</span>
          </h2>
          
          <div className="grid grid-cols-2 gap-3">
             {brandModels[selectedBrand].map((model) => (
               <button
                 key={model.name}
                 onClick={() => onSelectModel(model.name)}
                 className={`relative overflow-hidden rounded-xl h-20 px-4 transition-all duration-300 group flex items-center justify-between border
                   ${selectedModel === model.name 
                     ? 'bg-zinc-900 border-zinc-900 shadow-xl scale-[1.02]' 
                     : 'bg-white border-zinc-100 shadow-sm hover:shadow-md hover:border-red-200'}`}
               >
                 <div className="flex flex-col items-start gap-0.5">
                    <h3 className={`font-black text-base leading-none ${selectedModel === model.name ? 'text-white' : 'text-zinc-800 group-hover:text-red-600 transition-colors'}`}>
                      {model.name}
                    </h3>
                    <p className={`text-[9px] font-bold uppercase tracking-wider ${selectedModel === model.name ? 'text-zinc-500' : 'text-zinc-400'}`}>
                      Series
                    </p>
                 </div>

                 {selectedModel === model.name ? (
                    <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white shadow-lg animate-in zoom-in">
                      <ArrowRight className="w-4 h-4" />
                    </div>
                 ) : (
                    <div className={`w-1.5 h-1.5 rounded-full ${selectedModel === model.name ? 'bg-red-500' : 'bg-zinc-200 group-hover:bg-red-400'}`}></div>
                 )}
               </button>
             ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4 pt-4">
        <div onClick={() => onNavigate(AppMode.DECODER)} className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-3xl border border-blue-100 cursor-pointer hover:shadow-xl hover:-translate-y-1 transition-all group relative overflow-hidden">
          <div className="absolute -right-6 -top-6 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl group-hover:bg-blue-500/20 transition-colors"></div>
          <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center mb-4 text-blue-600 shadow-sm group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300 border border-blue-50">
             <Code2 className="w-7 h-7" />
          </div>
          <h3 className="font-black text-zinc-900 text-lg">{t.diagnostics}</h3>
          <p className="text-xs text-zinc-500 mt-1 font-medium leading-relaxed">ترجمة وتحليل أكواد الأعطال (MID/PID)</p>
        </div>

        <div onClick={() => onNavigate(AppMode.SENSORS)} className="bg-gradient-to-br from-emerald-50 to-teal-50 p-6 rounded-3xl border border-emerald-100 cursor-pointer hover:shadow-xl hover:-translate-y-1 transition-all group relative overflow-hidden">
          <div className="absolute -right-6 -top-6 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-colors"></div>
          <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center mb-4 text-emerald-600 shadow-sm group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-300 border border-emerald-50">
             <Activity className="w-7 h-7" />
          </div>
          <h3 className="font-black text-zinc-900 text-lg">{t.sensors}</h3>
          <p className="text-xs text-zinc-500 mt-1 font-medium leading-relaxed">مواقع الحساسات ووظائفها</p>
        </div>
      </div>
      
      {/* Footer / Credits */}
       <div className="mt-8 pt-8 text-center space-y-6">
        <div className="flex items-center justify-center gap-2 text-zinc-300 text-xs font-black uppercase tracking-[0.2em]">
           <Code2 className="w-3 h-3" />
           {t.programmedBy}
        </div>
        
        <div className="bg-white p-8 rounded-[2rem] shadow-xl shadow-zinc-200/50 border border-white inline-block w-full max-w-xs relative overflow-hidden group hover:shadow-2xl transition-shadow">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-zinc-900 to-red-500"></div>
          
          <div 
            className="w-20 h-20 bg-zinc-900 rounded-full mx-auto mb-4 flex items-center justify-center shadow-2xl shadow-zinc-900/30 text-white font-black text-2xl border-[4px] border-zinc-100 relative z-10 group-hover:scale-110 transition-transform"
            style={{ animation: 'spin3D 5s linear infinite' }}
          >
            SM
          </div>
          
          {/* Name Section */}
          <div className="relative mb-2 flex flex-col items-center gap-1">
            <style>{`
              @keyframes spin3D {
                from { transform: perspective(1000px) rotateY(0deg); }
                to { transform: perspective(1000px) rotateY(360deg); }
              }
            `}</style>

            {/* Name - Thin and Static */}
            <h3 className="font-light text-xl md:text-2xl text-zinc-800 font-sans tracking-widest">
              Samih Meguelati
            </h3>
          </div>
          
          {/* Replaced developer title with short Bio */}
          <p className="text-[10px] text-zinc-500 mb-6 font-medium max-w-[240px] mx-auto leading-relaxed px-2">
            {t.shortBio}
          </p>
          
          <div className="flex items-center justify-center gap-4">
             <a href="#" className="p-3 bg-zinc-50 rounded-2xl text-zinc-600 hover:text-black hover:bg-zinc-200 transition-all hover:-translate-y-1">
               <Github className="w-5 h-5" />
             </a>
             <a href="#" className="p-3 bg-zinc-50 rounded-2xl text-zinc-600 hover:text-blue-600 hover:bg-blue-50 transition-all hover:-translate-y-1">
               <Globe className="w-5 h-5" />
             </a>
          </div>
        </div>
        
        <p className="text-[10px] text-zinc-400 font-medium">
           © 2024 Smart Mechanic. All rights reserved.
        </p>
      </div>

      {/* PRO Upgrade Modal */}
      {showProModal && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
           <div className="bg-zinc-900 w-full md:max-w-md rounded-t-3xl md:rounded-3xl p-6 md:p-8 animate-in slide-in-from-bottom duration-300 relative overflow-hidden border border-zinc-800 shadow-2xl">
              <div className="absolute top-0 right-0 p-4 z-20">
                 <button onClick={() => setShowProModal(false)} className="bg-zinc-800 hover:bg-zinc-700 text-white p-2 rounded-full transition-colors">
                    <X className="w-5 h-5" />
                 </button>
              </div>

              {/* Gold Glow */}
              <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-64 h-64 bg-amber-500/20 rounded-full blur-[80px]"></div>

              <div className="relative z-10 text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-amber-300 to-yellow-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-amber-500/20 mb-4 rotate-3">
                   <Crown className="w-10 h-10 text-zinc-900 fill-zinc-900" />
                </div>
                <h2 className="text-3xl font-black text-white tracking-tight uppercase">Smart Mechanic <span className="text-amber-400">PRO</span></h2>
                <p className="text-zinc-400 mt-2 text-sm max-w-[80%] mx-auto">{t.proDesc}</p>
              </div>

              <div className="space-y-3 mb-8">
                 {[t.proFeature1, t.proFeature2, t.proFeature3, t.proFeature4].map((feature, idx) => (
                   <div key={idx} className="flex items-center gap-3 bg-zinc-800/50 p-3 rounded-xl border border-zinc-700/50">
                      <div className="w-5 h-5 bg-amber-500/20 rounded-full flex items-center justify-center shrink-0">
                         <Check className="w-3 h-3 text-amber-400" />
                      </div>
                      <span className="text-zinc-200 text-sm font-medium">{feature}</span>
                   </div>
                 ))}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                 <div className="bg-zinc-800 p-4 rounded-xl border-2 border-transparent hover:border-amber-500/50 cursor-pointer transition-colors text-center group">
                    <p className="text-zinc-400 text-xs font-bold uppercase mb-1">{t.monthly}</p>
                    <p className="text-white font-black text-xl">{t.priceMonth}</p>
                 </div>
                 <div className="bg-zinc-800 p-4 rounded-xl border-2 border-amber-500 cursor-pointer relative overflow-hidden text-center">
                    <div className="absolute top-0 right-0 bg-amber-500 text-zinc-900 text-[9px] font-black px-2 py-0.5 rounded-bl-lg">
                       {t.bestValue}
                    </div>
                    <p className="text-zinc-400 text-xs font-bold uppercase mb-1">{t.yearly}</p>
                    <p className="text-white font-black text-xl">{t.priceYear}</p>
                 </div>
              </div>

              <button 
                onClick={handleUpgradeClick}
                className="w-full py-4 bg-gradient-to-r from-amber-400 to-yellow-600 text-zinc-900 font-black rounded-xl text-lg hover:shadow-lg hover:shadow-amber-500/20 transition-all active:scale-[0.98] uppercase tracking-wide"
              >
                {t.subscribe}
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default HomeDashboard;
