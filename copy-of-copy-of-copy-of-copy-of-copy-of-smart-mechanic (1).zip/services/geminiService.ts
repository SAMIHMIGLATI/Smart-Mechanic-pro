
import { GoogleGenAI, Type } from "@google/genai";
import { DiagnosisResult, FaultCodeData, TruckBrand, Language } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-2.5-flash';

export const analyzeFaultCode = async (data: FaultCodeData, brand: TruckBrand, model: string | undefined, lang: Language): Promise<DiagnosisResult> => {
  const codeString = `MID ${data.mid} ${data.pid ? `PID ${data.pid}` : `SID ${data.sid}`} FMI ${data.fmi}`;
  const modelContext = model ? `Model ${model}` : '';
  
  let langContext = 'English';
  if (lang === 'ar') langContext = 'Arabic';
  if (lang === 'fr') langContext = 'French';

  const prompt = `
    You are a world-class expert truck mechanic specializing in ${brand} ${modelContext} trucks.
    Analyze the following fault code: ${codeString} for a ${brand} ${modelContext} truck.
    
    IMPORTANT: Provide the response strictly in ${langContext} language.
    
    Return the result in JSON format with the following fields:
    - system: Name of the affected system (e.g., Engine, Brakes).
    - description: Technical description of the fault.
    - symptoms: List of symptoms (array of strings).
    - causes: List of potential causes (array of strings).
    - solutions: Step-by-step repair instructions (array of strings).
    - severity: Severity level ("low", "medium", "high").
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            system: { type: Type.STRING },
            description: { type: Type.STRING },
            symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
            causes: { type: Type.ARRAY, items: { type: Type.STRING } },
            solutions: { type: Type.ARRAY, items: { type: Type.STRING } },
            severity: { type: Type.STRING, enum: ["low", "medium", "high"] }
          },
          required: ["system", "description", "solutions", "severity"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as DiagnosisResult;
  } catch (error) {
    console.error("Error analyzing fault code:", error);
    throw error;
  }
};

export const analyzeImageFault = async (base64Image: string, brand: TruckBrand, model: string | undefined, lang: Language): Promise<DiagnosisResult> => {
  const modelContext = model ? `Model ${model}` : '';
  
  let langContext = 'English';
  if (lang === 'ar') langContext = 'Arabic';
  if (lang === 'fr') langContext = 'French';

  const prompt = `
    You are an expert truck mechanic specializing in ${brand} ${modelContext}.
    Look at the provided image. It is likely a photo of a truck dashboard, a diagnostic tool screen showing a fault code, or a warning light.
    
    1. Identify any visible fault codes (MID, PID, FMI, SPN) or warning symbols.
    2. If a code is found, analyze it specifically for ${brand}.
    3. If a symbol is found, identify what it means.
    
    IMPORTANT: Provide the response strictly in ${langContext} language.

    Return the result in JSON format with the following fields:
    - system: Name of the affected system (e.g., Engine, Brakes).
    - description: Technical description of the fault found in the image.
    - symptoms: List of likely symptoms associated with this visual warning/code (array of strings).
    - causes: List of potential causes (array of strings).
    - solutions: Step-by-step repair instructions (array of strings).
    - severity: Severity level ("low", "medium", "high").
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg', // Assuming jpeg for simplicity, or we can pass the specific type
              data: base64Image
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            system: { type: Type.STRING },
            description: { type: Type.STRING },
            symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
            causes: { type: Type.ARRAY, items: { type: Type.STRING } },
            solutions: { type: Type.ARRAY, items: { type: Type.STRING } },
            severity: { type: Type.STRING, enum: ["low", "medium", "high"] }
          },
          required: ["system", "description", "solutions", "severity"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as DiagnosisResult;
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw error;
  }
};

export const sendChatMessage = async (history: { role: string, parts: { text: string }[] }[], message: string, brand: TruckBrand, model: string | undefined, lang: Language) => {
  try {
    const modelContext = model ? `Model ${model}` : '';
    let langContext = 'English';
    if (lang === 'ar') langContext = 'Arabic';
    if (lang === 'fr') langContext = 'French';

    const chat = ai.chats.create({
      model: MODEL_NAME,
      history: history,
      config: {
        systemInstruction: `You are a smart assistant and expert mechanic for heavy trucks, specifically ${brand} ${modelContext}. Answer technical questions accurately in ${langContext}. Always provide safety tips.`
      }
    });

    const result = await chat.sendMessage({ message });
    return result.text;
  } catch (error) {
    console.error("Chat error:", error);
    throw error;
  }
};
