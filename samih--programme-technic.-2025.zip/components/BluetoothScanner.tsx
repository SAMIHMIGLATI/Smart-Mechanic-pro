
import React, { useState, useEffect, useRef } from 'react';
import { Bluetooth, ArrowLeft, ArrowRight, Gauge, Zap, Thermometer, Activity, Lock, Check, Wifi } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { soundEngine } from '../utils/sound';

interface BluetoothScannerProps {
  lang: Language;
  onBack?: () => void;
}

const BluetoothScanner: React.FC<BluetoothScannerProps> = ({ lang, onBack }) => {
  const [connectionState, setConnectionState] = useState<'idle' | 'scanning' | 'pin' | 'connecting' | 'connected' | 'error'>('idle');
  const [logs, setLogs] = useState<string[]>([]);
  const [pin, setPin] = useState('');
  const [data, setData] = useState({ rpm: 0, speed: 0, temp: 0, voltage: 0 });
  
  const t = translations[lang];
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev, msg]);
  };

  const handleStartScan = () => {
    setConnectionState('scanning');
    setLogs([]);
    
    const scanSteps = [
      { msg: "Initializing Bluetooth Adapter...", delay: 500 },
      { msg: "Requesting Device Permissions...", delay: 1200 },
      { msg: "Permissions Granted.", delay: 1800 },
      { msg: "Scanning for OBDII Protocols...", delay: 2500 },
      { msg: "Checking Vehicle Voltage...", delay: 3200 },
      { msg: "Charger Detected: 13.8V [OK]", delay: 4000 },
      { msg: "Device Found: ELM327 v1.5", delay: 4800 },
    ];

    scanSteps.forEach(({ msg, delay }) => {
      setTimeout(() => {
        addLog(msg);
        soundEngine.playClick();
      }, delay);
    });

    setTimeout(() => {
      setConnectionState('pin');
    }, 5500);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length < 4) return;

    setConnectionState('connecting');
    addLog(`Secure Pairing with PIN: ****`);
    
    setTimeout(() => {
      addLog("Pairing Successful.");
      addLog("Handshake: ISO 15765-4 CAN (11/500)");
      addLog("ECU Connected.");
      soundEngine.playScan();
    }, 1500);

    setTimeout(() => {
      setConnectionState('connected');
      soundEngine.playSuccess();
      startDataStream();
    }, 3000);
  };

  const startDataStream = () => {
    const interval = setInterval(() => {
      setData({
        rpm: Math.floor(600 + Math.random() * 200),
        speed: Math.floor(0 + Math.random() * 5),
        temp: Math.floor(85 + Math.random() * 5),
        voltage: Number((13.8 + Math.random() * 0.4).toFixed(1))
      });
    }, 800);
    return () => clearInterval(interval);
  };

  return (
    <div className="bg-black min-h-screen text-green-500 font-mono p-4 pb-24 relative overflow-hidden">
      
      {/* Background Grid */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(0,255,0,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,0,0.1)_1px,transparent_1px)] bg-[size:20px_20px]"></div>

      {/* Header */}
      <div className="flex items-center justify-between border-b border-green-800/50 pb-4 mb-6 relative z-10">
        <div className="flex items-center gap-3">
           {onBack && (
              <button onClick={onBack} className="p-2 rounded hover:bg-green-900/30 text-green-400 transition-colors">
                 {lang === 'ar' ? <ArrowRight className="w-6 h-6" /> : <ArrowLeft className="w-6 h-6" />}
              </button>
           )}
           <div>
              <h2 className="text-xl font-bold tracking-wider text-white flex items-center gap-2">
                <Wifi className="w-5 h-5 text-green-500" />
                OBD II SCANNER
              </h2>
              <p className="text-[10px] text-green-600">v4.2.0 STABLE</p>
           </div>
        </div>
        <div className="flex items-center gap-2">
           <span className="text-[10px] text-green-700 hidden md:inline">{connectionState.toUpperCase()}</span>
           <div className={`w-3 h-3 rounded-full shadow-[0_0_10px_currentColor] ${connectionState === 'connected' ? 'bg-green-500 text-green-500 animate-pulse' : 'bg-red-500 text-red-500'}`}></div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-4xl mx-auto">
        
        {connectionState === 'idle' || connectionState === 'scanning' || connectionState === 'connecting' ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
             <div className="relative mb-12">
                <div className={`w-32 h-32 rounded-full border-4 flex items-center justify-center bg-black
                   ${connectionState !== 'idle' ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)]' : 'border-green-900'}`}>
                   <Bluetooth className={`w-12 h-12 text-white ${connectionState !== 'idle' ? 'animate-pulse' : ''}`} />
                </div>
                {(connectionState !== 'idle') && (
                   <>
                     <div className="absolute inset-0 border-4 border-green-500 rounded-full animate-ping opacity-20"></div>
                     <div className="absolute -inset-4 border border-green-900/50 rounded-full animate-[spin_3s_linear_infinite]"></div>
                   </>
                )}
             </div>
             
             <div className="bg-[#0a0a0a] border border-green-900/50 rounded-xl p-4 w-full max-w-md h-64 overflow-y-auto mb-8 font-mono text-xs shadow-inner custom-scrollbar">
                {logs.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-green-800">
                    Waiting for initialization...
                  </div>
                ) : (
                  logs.map((l, i) => (
                    <div key={i} className="mb-1 border-b border-green-900/20 pb-1 last:border-0">
                      <span className="text-green-700 mr-2">[{new Date().toLocaleTimeString().split(' ')[0]}]</span>
                      <span className="text-green-400">{l}</span>
                    </div>
                  ))
                )}
                <div ref={logsEndRef} />
             </div>
  
             {connectionState === 'idle' && (
               <button
                 onClick={handleStartScan}
                 className="px-10 py-4 bg-green-700 hover:bg-green-600 text-white font-bold rounded-lg uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(21,128,61,0.4)] hover:shadow-[0_0_30px_rgba(34,197,94,0.6)]"
               >
                 {t.connectObd}
               </button>
             )}
          </div>
        ) : connectionState === 'pin' ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] animate-in zoom-in duration-300">
             <div className="bg-zinc-900 border border-green-800 p-8 rounded-2xl max-w-sm w-full text-center shadow-2xl">
                <div className="w-16 h-16 bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/30">
                   <Lock className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-white font-bold text-xl mb-2">{t.enterPin}</h3>
                <p className="text-zinc-500 text-xs mb-6">Default PIN is usually 0000 or 1234</p>
                
                <form onSubmit={handlePinSubmit}>
                  <input 
                    type="text" 
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="0000"
                    className="w-full bg-black border-2 border-green-900 text-green-500 text-center text-3xl font-bold py-4 rounded-xl mb-6 focus:outline-none focus:border-green-500 transition-colors tracking-[1em]"
                    maxLength={4}
                    autoFocus
                  />
                  <button 
                    type="submit"
                    className="w-full bg-green-600 hover:bg-green-500 text-black font-bold py-4 rounded-xl transition-all shadow-lg uppercase tracking-wider"
                  >
                    {t.submit}
                  </button>
                </form>
             </div>
          </div>
        ) : (
          // Live Dashboard View
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
             {/* RPM Gauge */}
             <div className="bg-zinc-900/80 border border-green-800 p-8 rounded-3xl flex flex-col items-center shadow-[0_0_30px_rgba(34,197,94,0.1)] col-span-1 md:col-span-2 backdrop-blur-md">
                <div className="relative mb-4">
                   <Gauge className="w-16 h-16 text-green-500" strokeWidth={1.5} />
                   <div className="absolute inset-0 animate-pulse opacity-50 blur-md bg-green-500/20 rounded-full"></div>
                </div>
                <span className="text-6xl font-black text-white tracking-tighter tabular-nums">{data.rpm}</span>
                <span className="text-sm text-green-400 font-bold mt-2 tracking-[0.2em] uppercase">Engine RPM</span>
                
                <div className="w-full h-4 bg-black rounded-full mt-6 overflow-hidden border border-green-900/50 relative">
                   {/* RPM Ticks */}
                   <div className="absolute inset-0 flex justify-between px-1">
                      {[...Array(10)].map((_, i) => <div key={i} className="w-px h-full bg-green-900/50"></div>)}
                   </div>
                   <div className="h-full bg-gradient-to-r from-green-600 to-green-400 transition-all duration-300 ease-out shadow-[0_0_10px_rgba(34,197,94,0.5)]" style={{width: `${(data.rpm / 3000) * 100}%`}}></div>
                </div>
             </div>
  
             {/* Voltage */}
             <div className="bg-zinc-900/80 border border-green-800/50 p-6 rounded-2xl flex flex-col items-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-20"><Zap className="w-12 h-12 text-yellow-500" /></div>
                <Zap className="w-8 h-8 text-yellow-500 mb-2 relative z-10" />
                <span className="text-4xl font-bold text-white tabular-nums relative z-10">{data.voltage}</span>
                <span className="text-[10px] text-zinc-400 uppercase tracking-wider mt-1 relative z-10">Battery Voltage</span>
                <div className="w-full h-1.5 bg-zinc-800 rounded-full mt-4">
                   <div className="h-full bg-yellow-500 transition-all duration-500" style={{width: `${(data.voltage / 15) * 100}%`}}></div>
                </div>
             </div>
  
             {/* Coolant */}
             <div className="bg-zinc-900/80 border border-green-800/50 p-6 rounded-2xl flex flex-col items-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-20"><Thermometer className="w-12 h-12 text-red-500" /></div>
                <Thermometer className="w-8 h-8 text-red-500 mb-2 relative z-10" />
                <span className="text-4xl font-bold text-white tabular-nums relative z-10">{data.temp}°C</span>
                <span className="text-[10px] text-zinc-400 uppercase tracking-wider mt-1 relative z-10">Coolant Temp</span>
                <div className="w-full h-1.5 bg-zinc-800 rounded-full mt-4">
                   <div className="h-full bg-red-500 transition-all duration-500" style={{width: `${(data.temp / 120) * 100}%`}}></div>
                </div>
             </div>
  
             {/* Status */}
             <div className="bg-zinc-900/80 border border-green-800/50 p-4 rounded-xl flex flex-col items-center col-span-1 md:col-span-2">
                <div className="flex items-center gap-2 mb-1">
                   <Activity className="w-4 h-4 text-blue-400 animate-pulse" />
                   <span className="text-sm font-bold text-blue-400">SYSTEM OK</span>
                </div>
                <span className="text-[10px] text-zinc-500 font-mono">ECU LINK STABLE - NO FAULT CODES</span>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BluetoothScanner;
