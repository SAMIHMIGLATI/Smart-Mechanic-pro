
import React, { useState, useEffect } from 'react';
import { DiagnosisResult } from '../types';
import { AlertTriangle, Activity, CheckCircle2, AlertOctagon, Cpu, ListChecks, Wrench, Tag, ExternalLink } from 'lucide-react';

interface DiagnosisResultProps {
  result: DiagnosisResult | null;
}

// --- ORION PART CATALOG DATABASE (Extracted from PDF) ---
interface CatalogPart {
  partNumber: string;
  name: string;
  oemRefs: string[];
  model: string;
  category: string;
  imageUrl: string;
}

// Data extracted from OrionPart Renault Catalog PDF
const ORION_CATALOG: CatalogPart[] = [
  // --- COMPRESSORS & AIR ---
  {
    partNumber: "301250",
    name: "AIR COMPRESSOR",
    oemRefs: ["7421353473", "9125140040"],
    model: "RENAULT",
    category: "compressor",
    imageUrl: "https://orionpart.com/img/p/3/0/1/2/5/0/301250-large_default.jpg"
  },
  {
    partNumber: "301251",
    name: "AIR COMPRESSOR",
    oemRefs: ["5000793615"],
    model: "RENAULT MAJOR",
    category: "compressor",
    imageUrl: "https://orionpart.com/img/p/3/0/1/2/5/1/301251-large_default.jpg"
  },
  // --- VALVES ---
  {
    partNumber: "303070",
    name: "FOOT BRAKE VALVE",
    oemRefs: ["5021170165", "MB4630"],
    model: "RENAULT",
    category: "brake_valve",
    imageUrl: "https://orionpart.com/img/p/3/0/3/0/7/0/303070-large_default.jpg"
  },
  {
    partNumber: "302432",
    name: "ENGINE BRAKE VALVE REPAIR KIT",
    oemRefs: ["7421452473", "7421596642"],
    model: "RENAULT KERAX",
    category: "repair_kit",
    imageUrl: "https://orionpart.com/img/p/3/0/2/4/3/2/302432-large_default.jpg"
  },
  {
    partNumber: "303190",
    name: "CIRCUIT PROTECTION VALVE KIT",
    oemRefs: ["5000819919"],
    model: "RENAULT",
    category: "apm",
    imageUrl: "https://orionpart.com/img/p/3/0/3/1/9/0/303190-large_default.jpg"
  },
  {
    partNumber: "303082",
    name: "RELAY VALVE",
    oemRefs: ["7421583794"],
    model: "RENAULT",
    category: "relay_valve",
    imageUrl: "https://orionpart.com/img/p/3/0/3/0/8/2/303082-large_default.jpg"
  },
  {
    partNumber: "302105",
    name: "ECAS SOLENOID VALVE",
    oemRefs: ["5010143096", "4728800010"],
    model: "RENAULT",
    category: "solenoid",
    imageUrl: "https://orionpart.com/img/p/3/0/2/1/0/5/302105-large_default.jpg"
  },
  // --- TIE RODS ---
  {
    partNumber: "302241",
    name: "TIE ROD END",
    oemRefs: ["5000808458", "7701002911"],
    model: "RENAULT",
    category: "tie_rod",
    imageUrl: "https://orionpart.com/img/p/3/0/2/2/4/1/302241-large_default.jpg"
  },
  {
    partNumber: "301348",
    name: "TIE ROD END",
    oemRefs: ["5001830480"],
    model: "RENAULT",
    category: "tie_rod",
    imageUrl: "https://orionpart.com/img/p/3/0/1/3/4/8/301348-large_default.jpg"
  },
  // --- SENSORS ---
  {
    partNumber: "302018",
    name: "OIL PRESSURE SENSOR",
    oemRefs: ["7420514065"],
    model: "RENAULT",
    category: "oil_sensor",
    imageUrl: "https://orionpart.com/img/p/3/0/2/0/1/8/302018-large_default.jpg"
  },
  {
    partNumber: "301441",
    name: "WHEEL SPEED SENSOR",
    oemRefs: ["5010422332", "5430041687"],
    model: "RENAULT",
    category: "speed_sensor",
    imageUrl: "https://orionpart.com/img/p/3/0/1/4/4/1/301441-large_default.jpg"
  },
  {
    partNumber: "302186",
    name: "PRESSURE SWITCH",
    oemRefs: ["5001867660", "8200391398"],
    model: "RENAULT",
    category: "pressure_switch",
    imageUrl: "https://orionpart.com/img/p/3/0/2/1/8/6/302186-large_default.jpg"
  },
  // --- PUMPS & OTHER ---
  {
    partNumber: "302202",
    name: "SERVO PUMP",
    oemRefs: ["7421489078", "8694974624"],
    model: "RENAULT",
    category: "servo_pump",
    imageUrl: "https://orionpart.com/img/p/3/0/2/2/0/2/302202-large_default.jpg"
  },
  {
    partNumber: "301973",
    name: "FUEL HAND PUMP",
    oemRefs: ["5001832885"],
    model: "RENAULT",
    category: "hand_pump",
    imageUrl: "https://orionpart.com/img/p/3/0/1/9/7/3/301973-large_default.jpg"
  },
  {
    partNumber: "301209",
    name: "HEATING HOSE",
    oemRefs: ["5010421142"],
    model: "RENAULT PREMIUM",
    category: "hose",
    imageUrl: "https://orionpart.com/img/p/3/0/1/2/0/9/301209-large_default.jpg"
  }
];

const getOrionPart = (searchTerm: string | undefined): CatalogPart | null => {
  if (!searchTerm) return null;
  const term = searchTerm.toLowerCase().replace(/[^a-z0-9]/g, '');

  // Helper to check text match
  const matches = (target: string) => {
    const t = target.toLowerCase().replace(/[^a-z0-9]/g, '');
    return t.includes(term) || term.includes(t);
  };

  return ORION_CATALOG.find(p => {
    if (matches(p.name)) return true;
    if (term.includes('compressor') && p.category === 'compressor') return true;
    if (term.includes('brake') && term.includes('valve') && p.category === 'brake_valve') return true;
    if (term.includes('tie') && term.includes('rod') && p.category === 'tie_rod') return true;
    if (term.includes('oil') && term.includes('sensor') && p.category === 'oil_sensor') return true;
    if (term.includes('servo') && p.category === 'servo_pump') return true;
    if (term.includes('apm') && p.category === 'apm') return true;
    if (term.includes('relay') && p.category === 'relay_valve') return true;
    if (term.includes('solenoid') && p.category === 'solenoid') return true;
    if (term.includes('speed') && p.category === 'speed_sensor') return true;
    if (term.includes('fuel') && p.category === 'hand_pump') return true;
    
    return false;
  }) || null;
};

const DiagnosisResultCard: React.FC<DiagnosisResultProps> = ({ result }) => {
  const [catalogPart, setCatalogPart] = useState<CatalogPart | null>(null);
  
  useEffect(() => {
    if (result && result.partName) {
      const part = getOrionPart(result.partName);
      setCatalogPart(part);
    } else {
      setCatalogPart(null);
    }
  }, [result]);

  if (!result) return null;

  const severityConfig = {
    low: { color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: <CheckCircle2 className="w-8 h-8 text-emerald-500" />, label: 'Low Severity' },
    medium: { color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200', icon: <AlertTriangle className="w-8 h-8 text-amber-500" />, label: 'Medium Severity' },
    high: { color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200', icon: <AlertOctagon className="w-8 h-8 text-red-500" />, label: 'High Severity' }
  };

  const config = severityConfig[result.severity];
  const fallbackImage = "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?q=80&w=500&auto=format&fit=crop";

  return (
    <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700">
      
      {/* Diagnosis Header */}
      <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-zinc-100">
        <div className={`p-1 h-2 w-full ${result.severity === 'high' ? 'bg-red-500' : result.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 text-zinc-500 text-sm font-bold uppercase tracking-wider mb-2">
                <Cpu className="w-4 h-4" />
                {result.system}
              </div>
              <p className="text-zinc-600 leading-relaxed font-medium text-lg">{result.description}</p>
            </div>
            <div className={`flex flex-col items-center justify-center p-4 rounded-xl ${config.bg} border ${config.border} min-w-[140px] shrink-0`}>
              {config.icon}
              <span className={`mt-2 font-bold text-sm ${config.color}`}>{config.label}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ORION CATALOG PART CARD */}
      <div className="bg-zinc-900 rounded-xl shadow-2xl overflow-hidden border border-zinc-800 flex flex-col md:flex-row relative group">
          <div className="absolute top-0 right-0 bg-[#0099cc] text-white text-[10px] font-bold px-3 py-1 rounded-bl-xl z-20 uppercase tracking-wider flex items-center gap-1">
            <ExternalLink className="w-3 h-3" />
            OrionPart Catalog
          </div>

          <div className="p-6 flex-1 flex flex-col justify-center z-10">
            <div className="flex items-center gap-2 text-amber-500 text-xs font-bold uppercase tracking-widest mb-2">
                <Wrench className="w-4 h-4" />
                {catalogPart ? "Exact Part Identified" : "Suggested Component"}
            </div>
            
            {catalogPart ? (
              <>
                <h3 className="text-2xl font-black text-white mb-1 leading-tight">{catalogPart.name}</h3>
                <div className="flex items-center gap-3 mb-4">
                   <div className="flex items-center gap-1 bg-white/10 px-2 py-1 rounded text-sm text-white font-mono border border-white/10">
                      <Tag className="w-3 h-3 text-[#0099cc]" />
                      {catalogPart.partNumber}
                   </div>
                   <span className="text-zinc-500 text-sm">|</span>
                   <span className="text-zinc-400 text-sm">{catalogPart.model}</span>
                </div>
                
                <div className="bg-zinc-800/50 p-3 rounded-lg border border-zinc-700/50 mb-4">
                   <p className="text-zinc-500 text-[10px] uppercase font-bold mb-1">OEM Reference</p>
                   <div className="flex flex-wrap gap-2">
                      {catalogPart.oemRefs.map((ref, i) => (
                        <span key={i} className="text-zinc-300 font-mono text-xs bg-black/50 px-2 py-1 rounded border border-zinc-700">{ref}</span>
                      ))}
                   </div>
                </div>
              </>
            ) : (
              <div>
                 <h3 className="text-xl font-black text-white mb-2">{result.partName || 'General Inspection'}</h3>
                 <p className="text-zinc-400 text-sm">Specific OrionPart number pending. General component view shown.</p>
              </div>
            )}
          </div>
          
          <div className="w-full md:w-5/12 h-64 md:h-auto bg-white p-6 flex items-center justify-center relative">
               <img 
                  src={catalogPart ? catalogPart.imageUrl : fallbackImage} 
                  alt={catalogPart ? catalogPart.name : "Part"} 
                  className="w-full h-full object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-500" 
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = fallbackImage;
                  }}
               />
          </div>
      </div>

      {/* Repair Solutions */}
      <div className="bg-zinc-900 text-white p-6 rounded-xl shadow-xl">
          <div className="flex items-center gap-2 mb-6 border-b border-zinc-800 pb-4">
            <ListChecks className="w-6 h-6 text-green-400" />
            <h3 className="font-bold text-xl">Action Plan</h3>
          </div>
          <div className="space-y-4">
            {result.solutions.map((solution, idx) => (
              <div key={idx} className="flex items-start gap-4 bg-zinc-800/50 p-4 rounded-lg border border-zinc-700/50">
                <div className="w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">{idx + 1}</div>
                <p className="text-zinc-300 text-sm font-mono">{solution}</p>
              </div>
            ))}
          </div>
      </div>
    </div>
  );
};

export default DiagnosisResultCard;
