
import React from 'react';
import { Shield, Terminal, Globe, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black/95 border-t border-zinc-800 pt-10 pb-8 mt-12 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-32 bg-red-900/10 blur-[100px] pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col items-center text-center">
           
           {/* Developer Signature Section */}
           <div className="mb-8 animate-in fade-in duration-1000 delay-300">
              <div className="flex flex-col items-center gap-3">
                 <div className="p-2.5 bg-white/5 rounded-full border border-white/10 mb-1 shadow-lg">
                    <Terminal className="w-6 h-6 text-red-600" />
                 </div>
                 
                 <h3 className="text-2xl md:text-3xl font-black text-white font-cursive italic tracking-wide drop-shadow-lg">
                   Samih Pro Technik
                 </h3>
                 
                 <div className="h-px w-48 bg-gradient-to-r from-transparent via-red-500/50 to-transparent my-2"></div>
                 
                 <p className="text-zinc-400 text-[10px] md:text-xs font-bold uppercase tracking-widest opacity-80">
                   Producted by Samih Pro & Smart Technic & Smart Tash
                 </p>
              </div>
           </div>

           {/* Links */}
           <div className="flex flex-wrap justify-center gap-6 text-[10px] md:text-xs text-zinc-500 font-medium uppercase tracking-wider mb-8">
              <button 
                onClick={() => window.dispatchEvent(new Event('open-privacy'))}
                className="flex items-center gap-2 hover:text-white transition-colors group"
              >
                 <Shield className="w-3.5 h-3.5 text-zinc-600 group-hover:text-green-500 transition-colors" /> 
                 Privacy Policy
              </button>
              <button 
                onClick={() => window.dispatchEvent(new Event('open-terms'))}
                className="flex items-center gap-2 hover:text-white transition-colors group"
              >
                 <Globe className="w-3.5 h-3.5 text-zinc-600 group-hover:text-blue-500 transition-colors" /> 
                 Terms of Service
              </button>
              <button className="flex items-center gap-2 hover:text-white transition-colors group">
                 <Mail className="w-3.5 h-3.5 text-zinc-600 group-hover:text-amber-500 transition-colors" /> 
                 Contact Support
              </button>
           </div>

           {/* Copyright */}
           <p className="text-[10px] text-zinc-700 font-mono">
             © 2025 SMART MECHANIC PRO. ALL RIGHTS RESERVED.
           </p>
        </div>
      </div>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap');
        .font-cursive { font-family: 'Dancing Script', cursive; }
      `}</style>
    </footer>
  );
};

export default Footer;
