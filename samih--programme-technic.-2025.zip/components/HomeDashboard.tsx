
import React, { useState, useEffect, useRef } from 'react';
import { AppMode, TruckBrand, Language, User } from '../types';
import { Search, Code2, Gift, Share2, Info, LayoutDashboard, Activity, X, Coins, Lock, AlertCircle, CheckCircle2, ChevronRight, Clock, Wrench } from 'lucide-react';
import { translations } from '../utils/translations';
import { soundEngine } from '../utils/sound';
import SchematicViewer from './SchematicViewer';

interface HomeDashboardProps {
  onNavigate: (mode: AppMode) => void;
  onSearchRequest: (term: string) => void;
  selectedBrand?: TruckBrand;
  onSelectBrand: (brand: TruckBrand | undefined) => void;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  lang: Language;
  user: User | null;
  onUpgrade?: () => void;
  onAddPoints?: (amount: number) => void;
}

const brandLogos: Record<TruckBrand, string> = {
  Renault: 'https://cdn.simpleicons.org/renault/FFCC33',
  Volvo: 'https://cdn.simpleicons.org/volvo/14296C',
  Scania: 'https://cdn.simpleicons.org/scania/041E42',
  MAN: 'https://cdn.simpleicons.org/man/E40045',
  DAF: 'https://cdn.simpleicons.org/daf/005C94',
  Iveco: 'https://cdn.simpleicons.org/iveco/004899',
  Ford: 'https://cdn.simpleicons.org/ford/003399',
};

const truckModels: Record<TruckBrand, string[]> = {
  Renault: [
    'Rono 400', 'Premium 420 dCi', 'Premium 440 DXi', 'Premium 450 DXi', 'Premium 460 DXi',
    'Kerax 420 4x4', 'Kerax 440 4x4', 'Kerax 450 4x4', 'Kerax 460 4x4',
    'Magnum 440 DXi', 'Magnum 480 DXi', 'Magnum 500 DXi', 'Magnum 520 DXi',
    'Midlum 220 dCi', 'Midlum 270 DXi',
    'C 550 K (2025)', 'C 440 (2024)', 'T High 520 Evolution', 'K 520 Heavy'
  ],
  Volvo: [
    'FH Aero (2025)', 'FH 540 I-Save (2024)', 'FM 500 Electric', 
    'FH 500', 'FH 460', 'FMX 440 4x4', 'FH12 420', 'FMX 8x4'
  ],
  Scania: [
    'Super 560 R (2024)', '770 S V8', 'R450', 'G440', '113M 360', 'P-Series 4x4'
  ],
  MAN: [
    'TGX Individual Lion S (2024)', 'TGX 18.510', 'TGS 33.400', 'TGA 18.430', 'TGM 4x4'
  ],
  DAF: [
    'XG+ 530 (2024)', 'XF 480', 'XF 105.460', 'CF 85.410'
  ],
  Iveco: [
    'S-Way 570 (2024)', 'Stralis 450', 'Trakker 440 4x4', 'Eurocargo 180'
  ],
  Ford: [
    'F-MAX Select (2024)', 'F-MAX 500', 'Cargo 1848T'
  ],
};

const HomeDashboard: React.FC<HomeDashboardProps> = ({ 
  onNavigate, 
  onSearchRequest, 
  selectedBrand, 
  onSelectBrand,
  selectedModel,
  onSelectModel,
  lang,
  user,
  onUpgrade,
  onAddPoints
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [giftAvailable, setGiftAvailable] = useState(false);
  const [giftTimeLeft, setGiftTimeLeft] = useState('');
  const [showSchematicModal, setShowSchematicModal] = useState(false);
  const [showAboutSettings, setShowAboutSettings] = useState(false);
  const [showGiftVoucher, setShowGiftVoucher] = useState(false);
  const [highlightBrandSelect, setHighlightBrandSelect] = useState(false);
  
  const brandSectionRef = useRef<HTMLDivElement>(null);
  const t = translations[lang];

  const isPremiumModel = (model: string) => {
    return model.includes('2024') || model.includes('2025') || model.includes('Aero') || model.includes('Super');
  };

  useEffect(() => {
    const checkGiftStatus = () => {
      const lastClaim = localStorage.getItem('last_daily_gift');
      if (!lastClaim) {
        setGiftAvailable(true);
        setGiftTimeLeft("");
      } else {
        const lastDate = new Date(parseInt(lastClaim));
        const now = new Date();
        const diffMs = now.getTime() - lastDate.getTime();
        const cooldown = 9 * 60 * 60 * 1000; // 9 Hours
        
        if (diffMs >= cooldown) {
          setGiftAvailable(true);
          setGiftTimeLeft("");
        } else {
          setGiftAvailable(false);
          const remainingMs = cooldown - diffMs;
          const hours = Math.floor(remainingMs / (1000 * 60 * 60));
          const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((remainingMs % (1000 * 60)) / 1000);
          
          const h = hours.toString().padStart(2, '0');
          const m = minutes.toString().padStart(2, '0');
          const s = seconds.toString().padStart(2, '0');
          
          setGiftTimeLeft(`${h}:${m}:${s}`);
        }
      }
    };
    
    checkGiftStatus();
    const interval = setInterval(checkGiftStatus, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleClaimGift = () => {
    if (giftAvailable && onAddPoints) {
      onAddPoints(100);
      localStorage.setItem('last_daily_gift', Date.now().toString());
      setGiftAvailable(false);
      soundEngine.playSuccess();
      setShowGiftVoucher(true);
    }
  };

  const handleShareApp = async () => {
    const shareData = {
      title: 'Smart Mechanic Pro',
      text: 'Check out Smart Mechanic Pro - The best Truck Diagnostics App!',
      url: 'https://smart-mechanic-app.com'
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        if (onAddPoints) onAddPoints(50);
        soundEngine.playSuccess();
      } else {
        await navigator.clipboard.writeText(shareData.url);
        alert('Link copied! Share on WhatsApp/Messenger to earn points.');
        if (onAddPoints) onAddPoints(10);
        soundEngine.playSuccess();
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error(err);
        try {
           await navigator.clipboard.writeText(shareData.url);
           alert('Link copied! Share manually.');
        } catch (e) {}
      }
    }
  };

  const handleModelSelect = (model: string) => {
    if (isPremiumModel(model) && !user?.isPro) {
      soundEngine.playError();
      alert(lang === 'ar' ? 'هذا الموديل (2024/2025) متاح فقط لنسخة المحترفين (PRO)' : 'This 2024/2025 model is locked for PRO users only.');
      if (onUpgrade) onUpgrade();
      return;
    }
    onSelectModel(model);
    soundEngine.playClick();
  };

  const validateAndAct = (action: () => void) => {
    if (!selectedBrand) {
      soundEngine.playError();
      setHighlightBrandSelect(true);
      brandSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => setHighlightBrandSelect(false), 1500);
      return;
    }
    if (!selectedModel) {
      soundEngine.playError();
      alert(t.selectModelError || "Please select a model first");
      return;
    }
    action();
  };

  const handleDiagnosticClick = () => validateAndAct(() => onNavigate(AppMode.DECODER));
  const handleSchematicClick = () => validateAndAct(() => setShowSchematicModal(true));

  const DashboardCard = ({ title, icon, color, onClick, subtext, locked = false }: any) => (
    <button 
      onClick={onClick}
      className={`relative p-4 rounded-2xl border-t-4 shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-95 flex flex-col items-center justify-center gap-3 group bg-zinc-800 border-zinc-700 overflow-hidden h-full min-h-[160px]
        ${color === 'red' ? 'border-t-red-600' : 
          color === 'blue' ? 'border-t-blue-500' : 
          color === 'green' ? 'border-t-emerald-500' : 
          'border-t-amber-500'}`}
    >
      {locked && !user?.isPro && (
         <div className="absolute inset-0 bg-black/70 z-20 flex items-center justify-center backdrop-blur-[1px]">
            <Lock className="w-8 h-8 text-white/80" />
         </div>
      )}
      
      <div className={`w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center relative z-10 transition-transform group-hover:rotate-12
         ${color === 'red' ? 'bg-red-500/20 text-red-500' : 
           color === 'blue' ? 'bg-blue-500/20 text-blue-500' : 
           color === 'green' ? 'bg-emerald-500/20 text-emerald-500' : 
           'bg-amber-500/20 text-amber-500'}`}>
         {icon}
      </div>
      
      <div className="text-center relative z-10">
         <h3 className="text-white font-bold text-sm md:text-base uppercase tracking-wide leading-tight">{title}</h3>
         {subtext && <p className="text-zinc-400 text-[10px] mt-2 font-mono border-t border-white/10 pt-1">{subtext}</p>}
      </div>
    </button>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500 relative">
      
      {/* Hero Section - Dynamic Scanner */}
      <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/10 h-64 group bg-black">
        <img 
          src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?q=80&w=1600&auto=format&fit=crop" 
          alt="Scania Truck" 
          className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-red-600/30 to-transparent h-[10%] w-full animate-[scan-line_2s_linear_infinite] pointer-events-none border-t border-b border-red-500/60"></div>
        
        <div className="relative z-10 p-6 h-full flex flex-col justify-between">
          <div>
             <div className="flex items-center gap-2 mb-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                <span className="text-[10px] font-mono text-green-400">SYSTEM ONLINE</span>
             </div>
             <h1 className="text-4xl md:text-6xl font-black text-white tracking-tighter italic drop-shadow-lg">
               SMART <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-600">MECHANIC</span>
             </h1>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); if(searchTerm) onSearchRequest(searchTerm); }} className="relative max-w-md">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.quickSearch}
              className="w-full h-12 pl-12 pr-24 bg-black/50 border border-white/30 rounded-xl text-white placeholder-zinc-300 focus:border-red-500 focus:bg-black/80 outline-none backdrop-blur-md transition-all"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-300 w-5 h-5" />
            <button type="submit" className="absolute right-1 top-1 bottom-1 bg-red-600 hover:bg-red-500 text-white px-4 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors">
               SCAN
            </button>
          </form>
        </div>
      </div>

      {/* Step 1: Truck Selection */}
      <div ref={brandSectionRef} className={`space-y-4 p-4 rounded-3xl transition-all duration-500 ${highlightBrandSelect ? 'bg-red-900/20 ring-2 ring-red-500 shadow-[0_0_30px_rgba(220,38,38,0.3)]' : 'bg-zinc-900/50 border border-white/5'}`}>
        <div className="flex items-center justify-between">
          <h3 className="font-black text-white flex items-center gap-3 text-lg uppercase tracking-wider">
            <span className="bg-red-600 text-white px-3 py-1 rounded-lg text-xs shadow-lg">STEP 1</span>
            {t.selectBrand}
          </h3>
          {highlightBrandSelect && <span className="text-red-400 text-xs font-bold animate-pulse flex items-center gap-1"><AlertCircle className="w-4 h-4" /> {t.selectBrandError}</span>}
        </div>

        <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar snap-x">
          {(Object.keys(brandLogos) as TruckBrand[]).map((brand) => (
            <button
              key={brand}
              onClick={() => { onSelectBrand(selectedBrand === brand ? undefined : brand); soundEngine.playClick(); }}
              className={`relative snap-start flex-shrink-0 w-24 h-24 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all duration-300 group
                ${selectedBrand === brand 
                  ? 'bg-zinc-800 border-2 border-red-500 shadow-xl scale-105' 
                  : 'bg-white border-2 border-transparent hover:border-red-500/50 opacity-90 hover:opacity-100 hover:scale-105'}`}
            >
              <img src={brandLogos[brand]} alt={brand} className="w-10 h-10 object-contain group-hover:scale-110 transition-transform" />
              <span className={`text-[10px] font-bold uppercase tracking-widest ${selectedBrand === brand ? 'text-white' : 'text-black'}`}>{brand}</span>
              {selectedBrand === brand && <div className="absolute -top-2 -right-2 bg-green-500 text-white rounded-full p-1 shadow-md"><CheckCircle2 className="w-3 h-3" /></div>}
            </button>
          ))}
        </div>
        
        {selectedBrand && (
          <div className="bg-black/40 border border-white/10 rounded-2xl p-4 animate-in slide-in-from-top-4 duration-300">
             <div className="flex items-center justify-between mb-3">
                <h4 className="text-zinc-400 text-xs font-bold uppercase tracking-wider ml-1">{t.selectModel}</h4>
                <span className="text-[10px] text-amber-500 flex items-center gap-1"><Lock className="w-3 h-3" /> 2024+ Pro Only</span>
             </div>
             <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-48 overflow-y-auto custom-scrollbar">
                {truckModels[selectedBrand]?.map((model) => {
                  const isLocked = isPremiumModel(model) && !user?.isPro;
                  const isSelected = selectedModel === model;
                  return (
                    <button
                      key={model}
                      onClick={() => handleModelSelect(model)}
                      className={`text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex justify-between items-center group
                        ${isSelected
                           ? 'bg-red-600 text-white shadow-lg shadow-red-900/30' 
                           : isLocked 
                             ? 'bg-zinc-900/50 text-zinc-600 border border-zinc-800 cursor-not-allowed' 
                             : 'bg-zinc-800 text-zinc-300 border border-zinc-700 hover:bg-zinc-700 hover:text-white'}`}
                    >
                      <span className="truncate">{model}</span>
                      {isLocked ? <Lock className="w-3 h-3 text-amber-600" /> : isSelected && <CheckCircle2 className="w-3 h-3" />}
                    </button>
                  );
                })}
             </div>
          </div>
        )}
      </div>

      {/* Main Action Grid */}
      <div className="grid grid-cols-2 gap-4 md:gap-6">
        <DashboardCard 
           title={t.diagnostics} 
           icon={<Code2 className="w-8 h-8" />} 
           color="red" 
           subtext="MID/PID Decoder"
           onClick={handleDiagnosticClick} 
        />
        
        <DashboardCard 
           title={t.sensors} 
           icon={<Activity className="w-8 h-8" />} 
           color="blue" 
           subtext="Data & Location"
           onClick={() => onNavigate(AppMode.SENSORS)} 
        />
        
        <DashboardCard 
           title={t.truckSchematics} 
           icon={<LayoutDashboard className="w-8 h-8" />} 
           color="green" 
           subtext="Interactive Maps"
           onClick={handleSchematicClick} 
        />
        
        <DashboardCard 
           title={t.aboutApp} 
           icon={<Info className="w-8 h-8" />} 
           color="amber" 
           subtext="Settings & Dev"
           onClick={() => setShowAboutSettings(true)} 
        />
      </div>

      {/* Rewards & Gifts Section */}
      <div className="bg-gradient-to-r from-indigo-900 to-blue-900 rounded-2xl p-1 border border-indigo-500/30 shadow-2xl">
         <div className="bg-black/40 backdrop-blur-sm rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
               <div className="p-3 bg-indigo-500/20 rounded-full border border-indigo-500/50">
                  <Gift className="w-8 h-8 text-indigo-400 animate-bounce" />
               </div>
               <div>
                  <h3 className="text-white font-bold text-lg">{t.dailyGift}</h3>
                  <div className="flex items-center gap-2 text-xs font-mono">
                     {giftAvailable ? (
                       <span className="text-green-400 font-bold">{t.giftReady}</span>
                     ) : (
                       <>
                         <Clock className="w-3 h-3 text-zinc-400" />
                         <span className="text-indigo-200">{giftTimeLeft}</span>
                       </>
                     )}
                  </div>
               </div>
            </div>
            
            <div className="flex gap-3 w-full md:w-auto">
               <button 
                 onClick={handleClaimGift} 
                 disabled={!giftAvailable}
                 className={`flex-1 md:flex-none px-6 py-2 rounded-lg font-bold text-sm transition-all
                   ${giftAvailable 
                     ? 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-lg shadow-yellow-500/20' 
                     : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'}`}
               >
                 {t.redeem}
               </button>
               
               <button 
                 onClick={handleShareApp} 
                 className="flex-1 md:flex-none px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg font-bold text-sm transition-all flex items-center justify-center gap-2"
               >
                 <Share2 className="w-4 h-4" />
                 {t.shareWin}
               </button>
            </div>
         </div>
      </div>

      {/* Modals */}
      {showSchematicModal && selectedBrand && (
        <SchematicViewer 
           lang={lang} 
           onClose={() => setShowSchematicModal(false)} 
           modelName={selectedModel || `${selectedBrand} Series`}
        />
      )}
      
      {/* Gift Voucher Modal */}
      {showGiftVoucher && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-gradient-to-b from-amber-400 to-amber-600 w-full max-w-sm rounded-3xl p-1 shadow-2xl transform animate-in zoom-in-95 duration-300 relative">
             <button onClick={() => setShowGiftVoucher(false)} className="absolute top-3 right-3 z-10 bg-black/20 hover:bg-black/40 p-1 rounded-full text-white transition-colors">
               <X className="w-5 h-5" />
             </button>

             <div className="bg-zinc-900 rounded-[22px] p-6 text-center border border-amber-200/20 relative overflow-hidden">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-4 bg-amber-500/20 rounded-b-xl"></div>
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20"></div>
                
                <Gift className="w-20 h-20 text-amber-400 mx-auto mb-4 animate-bounce" />
                
                <h3 className="text-2xl font-black text-white uppercase tracking-widest mb-2">Gift Voucher</h3>
                <div className="text-4xl font-black text-amber-400 mb-2 drop-shadow-lg">+100</div>
                <p className="text-zinc-400 font-mono text-sm mb-6">SMART MECHANIC GEMS</p>
                
                <div className="h-12 bg-white rounded-lg mb-6 mx-4 flex items-center justify-center opacity-90 relative overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                       <span className="bg-white px-2 font-mono font-bold text-black text-xs tracking-widest">392-841-SM</span>
                    </div>
                </div>

                <button 
                  onClick={() => setShowGiftVoucher(false)}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-black rounded-xl uppercase tracking-wider shadow-lg transition-all active:scale-95"
                >
                  Collect
                </button>
             </div>
          </div>
        </div>
      )}

      {/* Settings / About Modal */}
      {showAboutSettings && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
           <div className="bg-zinc-900 w-full max-w-lg rounded-3xl border border-zinc-700 p-0 shadow-2xl overflow-hidden">
              <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-950/50">
                 <h2 className="text-xl font-black text-white uppercase tracking-wider">{t.settingsTitle}</h2>
                 <button onClick={() => setShowAboutSettings(false)} className="p-2 hover:bg-zinc-800 rounded-full transition-colors"><X className="w-6 h-6 text-zinc-400" /></button>
              </div>
              
              <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
                  {/* Developer Info with Signature Style */}
                  <div className="bg-zinc-800/50 p-5 rounded-2xl border border-zinc-700/50">
                     <h3 className="text-white font-bold mb-4 flex items-center gap-2 text-sm uppercase tracking-wider text-zinc-500">
                        Developer
                     </h3>
                     <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-black rounded-xl flex items-center justify-center font-black text-white border border-white/10 shadow-lg">
                           SP
                        </div>
                        <div>
                           <h4 className="font-black text-white text-2xl font-cursive italic">Samih Pro Technik</h4>
                           <p className="text-zinc-400 text-xs mt-1">Producted by Samih Pro & Smart Technic & Smart Tash</p>
                        </div>
                     </div>
                  </div>

                  {/* Gem Conversion */}
                  <div className="bg-amber-500/10 p-5 rounded-2xl border border-amber-500/20 relative overflow-hidden">
                     <div className="absolute top-0 right-0 p-4 opacity-10"><Coins className="w-24 h-24 text-amber-500" /></div>
                     <h3 className="text-amber-500 font-bold mb-2 flex items-center gap-2">
                        <Coins className="w-5 h-5"/> {t.convertGems}
                     </h3>
                     <p className="text-zinc-400 text-sm mb-4 relative z-10">{t.convertGemsDesc}</p>
                     <button 
                       onClick={() => { 
                         if(user?.points && user.points >= 500) { 
                           onAddPoints && onAddPoints(-500); 
                           onUpgrade && onUpgrade(); 
                           soundEngine.playSuccess();
                         } else { 
                           soundEngine.playError();
                           alert(t.insufficientGems); 
                         } 
                       }} 
                       className="w-full bg-amber-500 hover:bg-amber-400 text-black py-3 rounded-xl font-bold transition-colors shadow-lg relative z-10"
                     >
                       {t.convertBtn} (500 Gems)
                     </button>
                  </div>
              </div>
              <style>{`
                 @import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap');
                 .font-cursive { font-family: 'Dancing Script', cursive; }
              `}</style>
           </div>
        </div>
      )}
    </div>
  );
};

export default HomeDashboard;
