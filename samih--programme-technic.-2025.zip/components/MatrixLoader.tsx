
import React, { useEffect, useState } from 'react';
import { Truck, ScanLine, Cpu, ShieldCheck } from 'lucide-react';

interface MatrixLoaderProps {
  onFinish: () => void;
}

const MatrixLoader: React.FC<MatrixLoaderProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('INITIALIZING 3D ENGINE...');

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onFinish, 500);
          return 100;
        }
        
        // Dynamic status text based on progress
        if (prev === 20) setStatus('LOADING TRUCK MODELS...');
        if (prev === 50) setStatus('CONNECTING TO SATELLITE...');
        if (prev === 80) setStatus('VERIFYING ORION DATABASE...');
        
        return prev + 1;
      });
    }, 40);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center overflow-hidden perspective-1000">
      
      {/* 3D Rotating Truck Container */}
      <div className="relative w-64 h-64 flex items-center justify-center mb-12 animate-[float_6s_ease-in-out_infinite]">
        
        {/* Holographic Ring */}
        <div className="absolute inset-0 border-2 border-green-500/30 rounded-full animate-[spin-slow_10s_linear_infinite]"></div>
        <div className="absolute inset-4 border border-green-500/20 rounded-full animate-[spin_8s_linear_infinite_reverse]"></div>
        
        {/* The Truck Icon with 3D Rotation Effect */}
        <div className="relative z-10 animate-[rotate3d_8s_linear_infinite] transform-style-3d">
           <Truck className="w-32 h-32 text-green-500 drop-shadow-[0_0_25px_rgba(34,197,94,0.6)]" strokeWidth={1} />
           
           {/* Internal "Ghost" Truck for depth */}
           <Truck className="w-32 h-32 text-green-400/30 absolute top-0 left-0 translate-z-2" strokeWidth={1} />
        </div>

        {/* Scanning Laser Effect */}
        <div className="absolute inset-0 w-full h-full animate-[scan-vertical_2s_linear_infinite] bg-gradient-to-b from-transparent via-green-500/20 to-transparent pointer-events-none border-b-2 border-green-400/50"></div>
      
        {/* Floating Tech Icons */}
        <Cpu className="absolute -top-8 -right-8 w-8 h-8 text-green-700 animate-bounce delay-100 opacity-50" />
        <ShieldCheck className="absolute -bottom-8 -left-8 w-8 h-8 text-green-700 animate-bounce delay-300 opacity-50" />
      </div>

      {/* Text Info */}
      <h1 className="text-4xl font-black text-white tracking-tighter mb-2 drop-shadow-lg">
        SMART <span className="text-green-500">MECHANIC</span> PRO
      </h1>
      <p className="text-green-400/80 font-mono text-xs mb-8 tracking-widest animate-pulse">
        {status}
      </p>

      {/* Custom Progress Bar */}
      <div className="w-80 h-6 bg-zinc-900 rounded-full border border-green-900/50 relative overflow-hidden shadow-[0_0_20px_rgba(34,197,94,0.2)]">
        <div 
          className="h-full bg-gradient-to-r from-green-900 via-green-600 to-green-400 transition-all duration-75 ease-linear relative"
          style={{ width: `${progress}%` }}
        >
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-30"></div>
           {/* Glare effect */}
           <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-b from-white/20 to-transparent"></div>
        </div>
        
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <span className="text-[10px] font-bold text-white drop-shadow-md font-mono">
            {progress}%
          </span>
        </div>
      </div>

      <div className="mt-4 text-[10px] text-zinc-600 font-mono">
        SYSTEM V3.0.2 | SECURE CONNECTION
      </div>

      <style>{`
        @keyframes rotate3d {
          0% { transform: rotateY(0deg); }
          50% { transform: rotateY(180deg); }
          100% { transform: rotateY(360deg); }
        }
        @keyframes scan-vertical {
          0% { top: -100%; opacity: 0; }
          50% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
};

export default MatrixLoader;
