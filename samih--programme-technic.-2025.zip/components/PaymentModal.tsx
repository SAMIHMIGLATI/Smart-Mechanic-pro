
import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { X, CreditCard, Calendar, Lock, ShieldCheck, CheckCircle, Play } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { soundEngine } from '../utils/sound';

interface PaymentModalProps {
  onClose: () => void;
  onSuccess: () => void;
  lang: Language;
  plan: 'monthly' | 'yearly';
}

const PaymentModal: React.FC<PaymentModalProps> = ({ onClose, onSuccess, lang, plan }) => {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'google'>('card');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [name, setName] = useState('');
  const [googleCode, setGoogleCode] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const t = translations[lang];
  const price = plan === 'monthly' ? t.priceMonth : t.priceYear;

  const toEnglishDigits = (str: string) => {
    return str
      .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d).toString())
      .replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d).toString());
  };

  const handleGoogleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    value = value.substring(0, 16);
    const formatted = value.replace(/([A-Z0-9]{4})(?=[A-Z0-9])/g, '$1-');
    setGoogleCode(formatted);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (paymentMethod === 'google' && googleCode.length < 10) {
        alert("Invalid Code"); 
        return;
    }

    soundEngine.playClick();
    setIsProcessing(true);

    // Simulate API Call
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      soundEngine.playSuccess();
      setTimeout(() => {
        onSuccess();
      }, 1500);
    }, 2000);
  };

  return createPortal(
    <div className="fixed inset-0 z-[150] bg-black/95 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-zinc-900 w-full max-w-md rounded-3xl border border-zinc-700 shadow-2xl relative overflow-hidden">
          <button onClick={onClose} className="absolute top-4 right-4 text-zinc-400 hover:text-white"><X /></button>
          
          {isSuccess ? (
            <div className="p-12 text-center">
               <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4 animate-bounce" />
               <h2 className="text-2xl font-bold text-white">Activation Successful!</h2>
               <p className="text-zinc-400 mt-2">Welcome to Pro Mode.</p>
            </div>
          ) : (
            <div className="p-8">
               <h2 className="text-xl font-bold text-white mb-6 text-center flex items-center justify-center gap-2">
                  <Lock className="w-5 h-5 text-amber-500" /> Secure Payment
               </h2>

               <div className="flex gap-2 mb-6">
                  <button onClick={() => setPaymentMethod('card')} className={`flex-1 py-3 rounded-xl border text-sm font-bold ${paymentMethod === 'card' ? 'bg-white text-black' : 'bg-zinc-800 text-zinc-400 border-zinc-700'}`}>Card</button>
                  <button onClick={() => setPaymentMethod('google')} className={`flex-1 py-3 rounded-xl border text-sm font-bold ${paymentMethod === 'google' ? 'bg-green-600 text-white border-green-500' : 'bg-zinc-800 text-zinc-400 border-zinc-700'}`}>Google Code</button>
               </div>

               <form onSubmit={handleSubmit} className="space-y-4">
                  {paymentMethod === 'google' ? (
                     <div>
                        <label className="text-xs font-bold text-zinc-500 uppercase ml-1 mb-1 block">Activation Code</label>
                        <div className="relative">
                           <input 
                             value={googleCode}
                             onChange={handleGoogleCodeChange}
                             placeholder="XXXX-XXXX-XXXX-XXXX"
                             className="w-full bg-black border border-zinc-700 rounded-xl p-4 text-center text-lg font-mono text-green-500 tracking-widest focus:border-green-500 outline-none uppercase"
                           />
                        </div>
                     </div>
                  ) : (
                     <div className="text-center text-zinc-500 py-10 border-2 border-dashed border-zinc-800 rounded-xl">
                        Card payment simulated for demo.
                     </div>
                  )}

                  <button 
                    type="submit" 
                    disabled={isProcessing}
                    className="w-full bg-gradient-to-r from-red-600 to-red-500 text-white py-4 rounded-xl font-black text-lg shadow-lg mt-4 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                     {isProcessing ? "Verifying..." : "ACTIVATE NOW"}
                  </button>
               </form>
            </div>
          )}
      </div>
    </div>,
    document.body
  );
};

export default PaymentModal;
