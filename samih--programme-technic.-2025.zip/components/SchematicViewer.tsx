
import React, { useState } from 'react';
import { X, Layers, Zap, Wind, Activity, ZoomIn, ArrowLeft, ArrowRight, Cpu, AlertTriangle, Grid, FileText, Info } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { RENAULT_PDF_DATA } from '../data/pdfSchematics';

interface SchematicViewerProps {
  onClose: () => void;
  lang: Language;
  modelName: string;
}

const SchematicViewer: React.FC<SchematicViewerProps> = ({ onClose, lang, modelName }) => {
  const [activeTab, setActiveTab] = useState<'air' | 'elec' | 'engine' | 'dash'>('elec');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [selectedComponent, setSelectedComponent] = useState<any | null>(null);

  const t = translations[lang];

  const handleZoom = () => {
    setZoomLevel(prev => prev === 1 ? 1.5 : 1);
  };

  // Use PDF data if it's a Renault, otherwise generic (simulated for this example)
  const isRenault = modelName.toLowerCase().includes('renault') || modelName.toLowerCase().includes('rono');
  const pdfData = isRenault ? RENAULT_PDF_DATA : RENAULT_PDF_DATA; // Fallback to Renault data for demo

  const DetailPanel = () => {
    if (!selectedComponent) return null;
    return (
      <div className="absolute bottom-0 left-0 right-0 bg-zinc-900/95 backdrop-blur-xl border-t border-white/10 p-6 z-30 animate-in slide-in-from-bottom duration-300 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
         <div className="flex justify-between items-start mb-4">
            <div>
               <h3 className="text-xl font-bold text-white flex items-center gap-2">
                 <Info className="w-5 h-5 text-blue-500" />
                 {selectedComponent.title}
               </h3>
               <p className="text-zinc-400 text-xs font-mono mt-1">PDF EXTRACTED DATA</p>
            </div>
            <button onClick={() => setSelectedComponent(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
               <X className="w-5 h-5 text-white" />
            </button>
         </div>
         
         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-40 overflow-y-auto custom-scrollbar">
            {Object.entries(selectedComponent.data).map(([key, value]: [string, any]) => (
               <div key={key} className="bg-black/30 p-3 rounded-lg border border-white/5">
                  <span className="text-zinc-500 text-[10px] uppercase font-bold block mb-1">{key}</span>
                  <span className="text-white font-mono text-sm">{value}</span>
               </div>
            ))}
         </div>
      </div>
    );
  };

  const Hotspot = ({ top, left, onClick, label }: { top: string, left: string, onClick: () => void, label: string }) => (
    <button 
      onClick={onClick}
      className="absolute w-6 h-6 bg-red-500/80 rounded-full animate-pulse hover:scale-125 transition-transform cursor-pointer z-10 flex items-center justify-center shadow-[0_0_15px_rgba(220,38,38,0.6)] border-2 border-white"
      style={{ top, left }}
      title={label}
    >
       <div className="w-2 h-2 bg-white rounded-full"></div>
    </button>
  );

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-0 md:p-4 bg-black/95 backdrop-blur-lg animate-in fade-in">
      <div className="bg-zinc-900 w-full h-full md:h-[95vh] md:max-w-6xl md:rounded-3xl border border-zinc-700 shadow-2xl flex flex-col relative overflow-hidden">
        
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-950/80 backdrop-blur-md z-20">
           <div className="flex items-center gap-4">
              {/* Back to Home Button */}
              <button onClick={onClose} className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 rounded-xl text-white transition-colors shadow-lg font-bold text-sm">
                 {lang === 'ar' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                 {t.backToHome || "Back"}
              </button>
              
              <div className="h-8 w-px bg-zinc-700 mx-2"></div>

              <div>
                 <h2 className="text-xl font-bold text-white leading-none tracking-tight">{t.truckSchematics}</h2>
                 <div className="flex items-center gap-2 mt-1">
                   <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                   <p className="text-xs text-zinc-400 font-mono uppercase">{modelName} - PDF DATA SOURCE</p>
                 </div>
              </div>
           </div>
           <button onClick={onClose} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors">
             <X className="w-6 h-6" />
           </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-zinc-800 bg-zinc-900 z-20 overflow-x-auto">
           <button 
             onClick={() => setActiveTab('elec')}
             className={`flex-1 py-4 min-w-[100px] text-sm font-bold flex items-center justify-center gap-2 transition-all relative overflow-hidden
               ${activeTab === 'elec' ? 'text-yellow-400 bg-yellow-900/10' : 'text-zinc-500 hover:text-zinc-300'}`}
           >
             <Zap className="w-4 h-4" />
             {lang === 'ar' ? 'الكهرباء والصمامات' : 'Fuses & Elec'}
             {activeTab === 'elec' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-yellow-500"></div>}
           </button>
           <button 
             onClick={() => setActiveTab('engine')}
             className={`flex-1 py-4 min-w-[100px] text-sm font-bold flex items-center justify-center gap-2 transition-all relative overflow-hidden
               ${activeTab === 'engine' ? 'text-red-400 bg-red-900/10' : 'text-zinc-500 hover:text-zinc-300'}`}
           >
             <Activity className="w-4 h-4" />
             {t.engineParts}
             {activeTab === 'engine' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500"></div>}
           </button>
           <button 
             onClick={() => setActiveTab('dash')}
             className={`flex-1 py-4 min-w-[100px] text-sm font-bold flex items-center justify-center gap-2 transition-all relative overflow-hidden
               ${activeTab === 'dash' ? 'text-orange-400 bg-orange-900/10' : 'text-zinc-500 hover:text-zinc-300'}`}
           >
             <AlertTriangle className="w-4 h-4" />
             {lang === 'ar' ? 'التحذيرات' : 'Dashboard'}
             {activeTab === 'dash' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-500"></div>}
           </button>
           <button 
             onClick={() => setActiveTab('air')}
             className={`flex-1 py-4 min-w-[100px] text-sm font-bold flex items-center justify-center gap-2 transition-all relative overflow-hidden
               ${activeTab === 'air' ? 'text-blue-400 bg-blue-900/10' : 'text-zinc-500 hover:text-zinc-300'}`}
           >
             <Wind className="w-4 h-4" />
             {t.airSystem}
             {activeTab === 'air' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500"></div>}
           </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 relative bg-[#121212] overflow-hidden flex items-center justify-center">
           
           {/* Technical Grid Background */}
           <div className="absolute inset-0 opacity-20 pointer-events-none" 
                style={{ backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
           </div>

           <div 
             className="relative transition-transform duration-300 ease-out w-full h-full p-6 md:p-10 overflow-y-auto custom-scrollbar"
             style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top center' }}
           >
              
              {/* --- FUSES TAB --- */}
              {activeTab === 'elec' && (
                <div className="w-full max-w-4xl mx-auto">
                   <h3 className="text-yellow-500 font-bold text-xl mb-6 flex items-center gap-2">
                      <Grid className="w-6 h-6" /> FUSE BOX ALLOCATION (PASSENGER COMPARTMENT)
                   </h3>
                   
                   <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {pdfData.fuses.map((fuse) => (
                        <div 
                            key={fuse.id} 
                            className="bg-zinc-800/50 border border-yellow-500/20 p-4 rounded-lg hover:bg-zinc-800 transition-colors group cursor-pointer"
                            onClick={() => setSelectedComponent({ title: `Fuse ${fuse.id}`, data: { Function: fuse.function, Location: fuse.location } })}
                        >
                           <div className="flex justify-between items-start mb-2">
                              <div className="w-8 h-8 bg-yellow-500/10 rounded flex items-center justify-center text-yellow-500 font-bold border border-yellow-500/30">
                                 {fuse.symbol.charAt(0)}
                              </div>
                              <span className="text-xs font-mono text-zinc-500">#{fuse.id}</span>
                           </div>
                           <h4 className="text-white font-bold text-sm mb-1">{fuse.symbol}</h4>
                           <p className="text-xs text-zinc-400 leading-snug truncate">{fuse.function}</p>
                        </div>
                      ))}
                   </div>
                </div>
              )}

              {/* --- ENGINE TAB --- */}
              {activeTab === 'engine' && (
                <div className="w-full max-w-3xl mx-auto relative">
                   <h3 className="text-red-500 font-bold text-xl mb-6 flex items-center gap-2">
                      <Cpu className="w-6 h-6" /> ENGINE SPECIFICATIONS
                   </h3>

                   <div className="relative w-full h-96 bg-zinc-800/30 rounded-xl border border-white/5 overflow-hidden mb-6 flex items-center justify-center group">
                      <p className="text-zinc-600 font-black text-4xl opacity-20">ENGINE VIEW</p>
                      {/* Interactive Hotspots */}
                      <Hotspot 
                         top="40%" left="30%" label="Engine Block"
                         onClick={() => setSelectedComponent({ title: "Engine Block", data: { Code: pdfData.engine.type, Capacity: pdfData.engine.capacity } })} 
                      />
                      <Hotspot 
                         top="20%" left="50%" label="Injection System"
                         onClick={() => setSelectedComponent({ title: "Injection", data: { Type: pdfData.engine.injection, Fuel: pdfData.engine.fuel } })} 
                      />
                   </div>
                   
                   <div className="bg-zinc-800/50 border border-red-500/20 rounded-xl overflow-hidden">
                      <table className="w-full text-left">
                         <tbody className="divide-y divide-zinc-700">
                            <tr className="bg-zinc-800">
                               <td className="p-4 text-zinc-400 font-mono">Engine Code</td>
                               <td className="p-4 text-white font-bold">{pdfData.engine.type}</td>
                            </tr>
                            <tr>
                               <td className="p-4 text-zinc-400 font-mono">Oil Capacity</td>
                               <td className="p-4 text-white font-bold">{pdfData.engine.oilCapacity}</td>
                            </tr>
                         </tbody>
                      </table>
                   </div>
                </div>
              )}

              {/* --- DASHBOARD TAB --- */}
              {activeTab === 'dash' && (
                 <div className="w-full max-w-4xl mx-auto">
                    <h3 className="text-orange-500 font-bold text-xl mb-6 flex items-center gap-2">
                       <AlertTriangle className="w-6 h-6" /> WARNING LIGHTS & INDICATORS
                    </h3>

                    <div className="space-y-3">
                       {pdfData.lights.map((light, idx) => (
                          <div key={idx} className="flex items-center gap-4 bg-zinc-800/50 p-4 rounded-xl border border-zinc-700 hover:bg-zinc-800 transition-colors">
                             <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center text-2xl shadow-inner border border-zinc-700">
                                {light.icon}
                             </div>
                             <div className="flex-1">
                                <h4 className="text-white font-bold">{light.name}</h4>
                                <p className="text-zinc-400 text-sm">{light.description}</p>
                             </div>
                             <div className="hidden md:block px-4 py-2 bg-red-900/20 text-red-400 text-xs font-bold rounded-lg border border-red-900/50 uppercase">
                                {light.action}
                             </div>
                          </div>
                       ))}
                    </div>
                 </div>
              )}

              {/* --- AIR SYSTEM TAB --- */}
              {activeTab === 'air' && (
                <div className="w-full max-w-4xl mx-auto relative h-[600px] border border-blue-500/30 rounded-xl bg-blue-900/5">
                   <div className="absolute top-20 left-20">
                      <div 
                         className="relative group cursor-pointer"
                         onClick={() => setSelectedComponent({ title: "APM Unit", data: { Type: "Air Production Management", Ref: "5010422397" } })}
                      >
                        <div className="w-32 h-24 bg-zinc-800 border-2 border-blue-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.3)] hover:bg-zinc-700">
                           <Wind className="w-10 h-10 text-blue-400" />
                        </div>
                        <Hotspot top="-10px" left="-10px" onClick={() => {}} label="APM" />
                      </div>
                   </div>

                   {/* Pipes SVG */}
                   <svg className="absolute inset-0 pointer-events-none overflow-visible">
                      <path d="M150 120 L150 350 L450 350" stroke="#3B82F6" strokeWidth="4" fill="none" />
                      <circle cx="150" cy="120" r="4" fill="#3B82F6" />
                   </svg>
                </div>
              )}
           </div>
           
           <DetailPanel />

           {/* Zoom Controls */}
           <div className="absolute bottom-8 right-8 flex flex-col gap-2 z-40">
              <button onClick={handleZoom} className="p-4 bg-zinc-800 hover:bg-zinc-700 text-white rounded-full shadow-xl border border-zinc-600 transition-transform active:scale-95">
                 <ZoomIn className="w-6 h-6" />
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default SchematicViewer;
