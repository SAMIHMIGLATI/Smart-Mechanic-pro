
import React, { useEffect, useState } from 'react';
import { Truck } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('System Check...');

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const increment = Math.random() * 2 + 1; 
        const newProgress = Math.min(prev + increment, 100);

        if (newProgress < 20) setStatusText('Loading Core Modules...');
        else if (newProgress < 40) setStatusText('Verifying Integrity...');
        else if (newProgress < 60) setStatusText('Loading Assets...');
        else if (newProgress < 80) setStatusText('Initializing AI Engine...');
        else if (newProgress < 99) setStatusText('Finalizing Setup...');
        else setStatusText('Ready to Launch');

        if (newProgress >= 100) {
          clearInterval(timer);
          setTimeout(onFinish, 1200); 
          return 100;
        }
        return newProgress;
      });
    }, 30);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div 
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center relative overflow-hidden"
      style={{ backgroundColor: '#121212' }}
    >
      {/* Logo @id/logo */}
      <div className="w-[170px] h-[170px] flex items-center justify-center mb-[18px] animate-in zoom-in duration-700">
        <div className="w-full h-full bg-white/5 rounded-3xl flex items-center justify-center border border-white/10 shadow-2xl relative group">
           <div className="absolute inset-0 bg-red-600/20 blur-xl rounded-full opacity-50 group-hover:opacity-75 transition-opacity"></div>
           <Truck className="w-24 h-24 text-red-600 relative z-10" strokeWidth={1.5} />
        </div>
      </div>

      {/* App Name @id/appName */}
      <h1 
        className="text-white text-2xl font-bold tracking-wide animate-in slide-in-from-bottom-4 duration-700 delay-100"
        style={{ fontFamily: 'Roboto, sans-serif' }}
      >
        Samih Tash System Pro
      </h1>

      {/* Tagline @id/tagline */}
      <p 
        className="text-sm mt-[6px] mb-4 animate-in slide-in-from-bottom-2 duration-700 delay-200 font-medium"
        style={{ color: 'rgba(255, 255, 255, 0.7)' }}
      >
        Advanced Diagnostics & Pro Tech
      </p>

      {/* Description @id/description */}
      <p 
        className="text-xs text-center max-w-xs leading-relaxed mb-10 animate-in fade-in duration-700 delay-300 px-4"
        style={{ color: 'rgba(255, 255, 255, 0.5)' }}
      >
        تطبيق احترافي لصيانة وتشخيص أعطال الشاحنات، يساعد الميكانيكيين على فحص المحرك وإصلاح الأعطال بدقة.
      </p>

      {/* Progress Bar */}
      <div className="w-64 relative flex flex-col gap-2 animate-in fade-in duration-700 delay-400">
        <div className="flex justify-between items-center w-full px-1">
           <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">{statusText}</span>
           <span className="text-xs font-mono font-bold text-white">{Math.floor(progress)}%</span>
        </div>
        <div className="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
           <div 
             className="h-full bg-red-600 shadow-[0_0_10px_rgba(220,38,38,0.5)] transition-all duration-100 ease-linear"
             style={{ width: `${progress}%` }}
           />
        </div>
      </div>

      {/* Signature @id/signature */}
      <div 
        className="absolute bottom-8 left-0 right-0 text-center animate-in fade-in duration-1000 delay-500"
        style={{ 
            color: 'rgba(255, 255, 255, 0.4)', 
            fontSize: '12px',
            fontStyle: 'italic'
        }}
      >
        Samih Pro Technic
      </div>
    </div>
  );
};

export default SplashScreen;
