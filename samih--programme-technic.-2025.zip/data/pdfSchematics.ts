
import { TruckBrand } from "../types";

export interface FuseItem {
  id: string;
  symbol: string;
  function: string;
  location: string;
}

export interface EngineDetails {
  type: string;
  capacity: string;
  injection: string;
  fuel: string;
  oilCapacity: string;
  firingOrder: string;
}

export interface WarningLight {
  icon: string;
  name: string;
  description: string;
  action: string;
}

// Data extracted from Renault MASTER Vehicle user manual PDF
export const RENAULT_PDF_DATA = {
  engine: {
    type: "M9T (2.3 dCi)",
    capacity: "2,299 cc",
    injection: "Direct Diesel Injection",
    fuel: "Diesel (EN 590)",
    oilCapacity: "8.0 Liters (approx)",
    firingOrder: "1-3-4-2"
  } as EngineDetails,
  
  fuses: [
    { id: "1", symbol: "Radio", function: "Radio, Heated Seats, Alarm", location: "Passenger Compartment" },
    { id: "2", symbol: "Lights", function: "Brake Lights, Interior Lighting", location: "Passenger Compartment" },
    { id: "3", symbol: "UCH", function: "Passenger Compartment ECU", location: "Passenger Compartment" },
    { id: "4", symbol: "Socket", function: "Accessories Socket (12V)", location: "Passenger Compartment" },
    { id: "5", symbol: "Cigar", function: "Cigar Lighter", location: "Passenger Compartment" },
    { id: "6", symbol: "Dash", function: "Instrument Panel", location: "Passenger Compartment" },
    { id: "7", symbol: "Heat", function: "Rear Screen / Mirror Defrost", location: "Passenger Compartment" },
    { id: "8", symbol: "ABS", function: "ABS / ESC System", location: "Engine Compartment" },
    { id: "9", symbol: "Wiper", function: "Windscreen Wiper/Washer", location: "Passenger Compartment" },
    { id: "10", symbol: "Win", function: "Electric Windows", location: "Passenger Compartment" },
    { id: "11", symbol: "Tacho", function: "Tachograph", location: "Passenger Compartment" },
    { id: "12", symbol: "Start", function: "Engine Immobiliser", location: "Passenger Compartment" }
  ] as FuseItem[],

  lights: [
    { icon: "🛑", name: "STOP Light", description: "Stop immediately. Engine or Brake fault.", action: "Stop engine, contact dealer." },
    { icon: "🔧", name: "Service Light", description: "Minor fault or maintenance required.", action: "Drive carefully to dealer." },
    { icon: "🛢️", name: "Oil Pressure", description: "Low oil pressure.", action: "Stop and check oil level." },
    { icon: "🌡️", name: "Coolant Temp", description: "Engine overheating.", action: "Stop, let engine cool down." },
    { icon: "🔋", name: "Battery", description: "Charging circuit fault.", action: "Check alternator belt." },
    { icon: "💨", name: "Exhaust Filter", description: "DPF Regeneration needed.", action: "Drive at highway speeds." },
    { icon: "ABS", name: "Anti-Lock Braking", description: "ABS system fault.", action: "Braking still works, but without ABS." }
  ] as WarningLight[]
};
