
import { GoogleGenAI, Type } from "@google/genai";
import { DiagnosisResult, FaultCodeData, TruckBrand, Language } from "../types";

const apiKey = process.env.API_KEY;
const ai = apiKey && apiKey.length > 0 ? new GoogleGenAI({ apiKey }) : null;
const MODEL_NAME = 'gemini-2.5-flash';

const RENAULT_STANDARD_CONTEXT = `
  REFERENCE DOCUMENT: **Renault Trucks Standard 70 627**.
  CATALOG: **OrionPart Spare Parts Catalog**.
  
  **CRITICAL INSTRUCTION:**
  You MUST map the diagnosis to one of these EXACT strings found in the OrionPart Catalog if applicable:
  - "AIR COMPRESSOR"
  - "FOOT BRAKE VALVE"
  - "ENGINE BRAKE VALVE REPAIR KIT"
  - "TIE ROD END"
  - "OIL PRESSURE SENSOR"
  - "WHEEL SPEED SENSOR"
  - "SERVO PUMP"
  - "FUEL HAND PUMP"
  - "CIRCUIT PROTECTION VALVE KIT"
  - "RELAY VALVE"
  - "RADIATOR HOSE"
  - "WATER PUMP"
  - "CLUTCH SERVO"
  
  If the fault code is MID 128 PID 94, output "FUEL HAND PUMP" or "FUEL PRESSURE SENSOR".
  If MID 144 PID 91, output "ACCELERATOR PEDAL SENSOR".
  If MID 136 SID 1/2/3, output "WHEEL SPEED SENSOR".
`;

const getMockDiagnosis = (lang: Language): DiagnosisResult => {
  return {
    system: "Engine Management (MID 128)",
    description: "Simulated Fault: Oil Pressure Low. Sensor reading below threshold.",
    symptoms: ["Red Stop Light", "Gauge dropping"],
    causes: ["Faulty Sensor", "Low Oil Level", "Wiring Short"],
    solutions: ["Check Oil Level", "Inspect Sensor Wiring", "Replace Sensor"],
    severity: "high",
    partName: "OIL PRESSURE SENSOR"
  };
};

export const analyzeFaultCode = async (data: FaultCodeData, brand: TruckBrand, model: string | undefined, lang: Language): Promise<DiagnosisResult> => {
  if (!ai) {
    await new Promise(resolve => setTimeout(resolve, 1500));
    return getMockDiagnosis(lang);
  }

  const codeString = `MID ${data.mid} ${data.pid ? `PID ${data.pid}` : data.sid ? `SID ${data.sid}` : ''} FMI ${data.fmi}`;
  const langInstruction = lang === 'ar' ? 'Output Language: Arabic' : lang === 'fr' ? 'Output Language: French' : 'Output Language: English';

  const prompt = `
    ROLE: Expert Truck Diagnostician using OrionPart Catalog.
    ${RENAULT_STANDARD_CONTEXT}
    INPUT: ${codeString} for ${brand} ${model || ''}.
    
    TASK:
    1. Identify the fault based on Renault Standard 70 627.
    2. **IMPORTANT**: Select the matching spare part from the OrionPart list above.
    3. Provide electrical troubleshooting steps.

    ${langInstruction}
    
    RETURN JSON:
    {
      "system": "System Name",
      "description": "Technical Description",
      "symptoms": ["Symptom 1", "Symptom 2"],
      "causes": ["Cause 1", "Cause 2"],
      "solutions": ["Step 1", "Step 2"],
      "severity": "low" | "medium" | "high",
      "partName": "EXACT_CATALOG_NAME_FROM_LIST"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || '{}') as DiagnosisResult;
  } catch (e) {
    return getMockDiagnosis(lang);
  }
};

export const analyzeImageFault = async (base64Image: string, brand: TruckBrand, model: string | undefined, lang: Language): Promise<DiagnosisResult> => {
  if (!ai) return getMockDiagnosis(lang);
  
  const prompt = `
    ROLE: Spare Parts Specialist using OrionPart Catalog.
    ${RENAULT_STANDARD_CONTEXT}
    ANALYZE IMAGE: Identify the truck part or fault code screen.
    If it is a physical part, match it to the Orion Catalog names (e.g. "AIR COMPRESSOR", "TIE ROD END", "RELAY VALVE").
    Return JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: { parts: [{ inlineData: { mimeType: 'image/jpeg', data: base64Image } }, { text: prompt }] },
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || '{}') as DiagnosisResult;
  } catch (e) {
    return getMockDiagnosis(lang);
  }
};

export const sendChatMessage = async (history: any[], message: string, brand: TruckBrand, model: string | undefined, lang: Language) => {
  return "Chat Simulated."; 
};
